/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zeeme.games;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.microedition.midlet.MIDlet;

import zmachine.ui.ZeeMEMidlet;

/**
 * The game catalog implementation for packaged games.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/08/31 21:47:16 $
 * <br>
 * @author Craig Setera
 */
public class GameCatalog {
	/** 
	 * The maximum number games that we will look for in
	 * the jar file.
	 */
	public static final int MAX_GAME_COUNT = 10;

	// Manifest key prefixes
	private static final String GAMEFILE_KEY = "GameFile";
	private static final String GAMETITLE_KEY = "GameTitle";
	private static final String GAMELENGTH_KEY = "GameLength";
	
	// Singleton instance of the GameLoader
	private static GameCatalog singleton;
	
	/**
	 * Return the singleton instance of the GameLoader.
	 * 
	 * @param midlet
	 * @return
	 */
	public static GameCatalog getInstance(ZeeMEMidlet midlet) 
	{
		if (singleton == null) {
			singleton = new GameCatalog(midlet);
		}
		
		return singleton;
	}
	
	// The game names and file names
	private Hashtable games;
	
	// Private constructor for singleton access
	private GameCatalog(ZeeMEMidlet midlet) {
		// initialize the instance variable
		initMappings(midlet);
	}

	/**
	 * Return a list of the games packaged in the
	 * jar file.
	 * 
	 * @return
	 */
	public Enumeration getGameTitles()
	{
		return games.keys();
	}

	/**
	 * Return the game information for the game with the
	 * specified name.
	 * 
	 * @param name
	 * @return
	 */
	public GameDefinition getGameInfo(String name) {
		return (GameDefinition) games.get(name);
	}
	
	/**
	 * Initialize the instance variables 
	 */
	private void initMappings(MIDlet midlet) {
		games = new Hashtable();

		for (int i = 0; i < MAX_GAME_COUNT; i++) {
			String title = midlet.getAppProperty(GAMETITLE_KEY + i);
			String file = midlet.getAppProperty(GAMEFILE_KEY + i);
			String length = midlet.getAppProperty(GAMELENGTH_KEY + i);
			
			if ((title != null) && (file != null) && (length != null)) {
				int lengthInt = 0;
				try {
					lengthInt = Integer.parseInt(length);
				} catch (NumberFormatException e) { }
				
				GameDefinition info = new GameDefinition(title, file, lengthInt);
				games.put(title, info);
			}
		}
	}
}
