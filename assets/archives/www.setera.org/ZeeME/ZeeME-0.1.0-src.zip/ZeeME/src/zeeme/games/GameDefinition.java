/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zeeme.games;

import java.io.IOException;
import java.io.InputStream;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Gauge;
import javax.microedition.lcdui.Item;

/**
 * A simple structure holding information about a game
 * and its related code.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/08/31 21:47:16 $
 * <br>
 * @author Craig Setera
 */
public class GameDefinition {
	// The size of blocks to be read for each read cycle.
	private static final int READ_BLOCK_SIZE = 1024;
	
	/** Runnable for loading the game ZCode */
	class GameLoadRunnable implements Runnable {
		private Display display;
		private Runnable callback;
		
		public GameLoadRunnable(Display display, Runnable callback) {
			this.display = display;
			this.callback = callback;
		}

		/**
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			int bytesRead = 0;
			code = new byte[length];

			// Create the loading gauge...
			String label = "Loading " + name + "...";
			Gauge gauge = new Gauge(label, false, length, 0);
			Form form = new Form("Game load", new Item[] { gauge });
			display.setCurrent(form);

			InputStream codeStream = getClass().getResourceAsStream(filename);
			if (codeStream != null) {
				try {
					while (bytesRead < length) {
						int toRead = length - bytesRead;
						if (toRead > READ_BLOCK_SIZE) toRead = READ_BLOCK_SIZE;
						
						bytesRead += codeStream.read(code, bytesRead, toRead);
						gauge.setValue(bytesRead);
					}
					
					codeStream.close();
					
					callback.run();
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	// Instance variables
	public String name;
	public String filename;
	public int length;
	public byte[] code;
	
	public GameDefinition(String name, String filename, int length) {
		this.name = name;
		this.filename = filename;
		this.length = length;
	}

	/**
	 * Read in the code and call the callback when finished.
	 * 
	 * @param display
	 * @param callback
	 */
	public void readCode(Display display, Runnable callback) {
		GameLoadRunnable runner = new GameLoadRunnable(display, callback);
		Thread thread = new Thread(runner);
		thread.start();
	}
}