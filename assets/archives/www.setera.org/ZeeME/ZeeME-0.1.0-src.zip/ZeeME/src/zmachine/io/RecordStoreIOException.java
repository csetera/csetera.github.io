/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.io;

import java.io.IOException;

import javax.microedition.rms.RecordStoreException;

/**
 * IOException wrapper around a RecordStoreException.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/01/18 23:16:46 $
 * <br>
 * @author Craig Setera
 */
public class RecordStoreIOException extends IOException {
	private RecordStoreException detail;
	
	/**
	 * Constructor
	 * 
	 * @param e
	 */
	public RecordStoreIOException(RecordStoreException e) {
		super(e.getMessage());
		e.printStackTrace();
		detail = e;
	}

	/**
	 * Get the IOException that caused this IOException
	 * @return
	 */
	public RecordStoreException getDetail() {
		return detail;
	}

}
