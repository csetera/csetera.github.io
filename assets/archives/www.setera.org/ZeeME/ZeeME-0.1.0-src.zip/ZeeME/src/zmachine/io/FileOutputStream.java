/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.io;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Minimal FileOutputStream implementation that wraps the
 * J2ME record store.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/01/18 23:16:46 $
 * <br>
 * @author Craig Setera
 */
public class FileOutputStream extends OutputStream {
	private File file;
	private ByteArrayOutputStream stream;
	
	/**
	 * Constructor
	 * 
	 * @param fn
	 */
	public FileOutputStream(String fn) {
		file = new File(fn);
		stream = new ByteArrayOutputStream();
	}

	/**
	 * @see java.io.OutputStream#write(int)
	 */
	public void write(int arg0) throws IOException {
		stream.write(arg0);
	}

	/**
	 * @see java.io.OutputStream#close()
	 */
	public void close() throws IOException {
		file.writeRecordData(stream.toByteArray());
	}

	/**
	 * @see java.io.OutputStream#flush()
	 */
	public void flush() throws IOException {
		stream.flush();
	}

	/**
	 * @see java.io.OutputStream#write(byte[], int, int)
	 */
	public void write(byte[] arg0, int arg1, int arg2) throws IOException {
		stream.write(arg0, arg1, arg2);
	}

	/**
	 * @see java.io.OutputStream#write(byte[])
	 */
	public void write(byte[] arg0) throws IOException {
		stream.write(arg0);
	}
}
