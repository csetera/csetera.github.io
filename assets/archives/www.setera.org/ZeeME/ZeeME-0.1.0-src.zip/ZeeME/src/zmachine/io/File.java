/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;
import javax.microedition.rms.RecordStoreNotFoundException;

/**
 * Minimal java.io.File implementation that wraps the J2ME
 * record store with just enough functionality to implement
 * Zax on J2ME.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/01/18 23:16:46 $
 * <br>
 * @author Craig Setera
 */
public class File {
	public static final String NAME_STORE = "zaxme_names";
	public static final String DATA_STORE = "zaxme_data";
	
	private static final Vector EMPTY_VECTOR = new Vector();
	private static RecordStore namesStore;
	private static RecordStore dataStore;
	private static int namesRecordID = -1;
	private static Hashtable nameToIdMapping;

	/**
	 * Get all of the registered names.
	 * @return
	 */	
	public static Enumeration getAllNames() {
		Enumeration names = null;

		try {
			names = getNameToIdMappings().keys();
		} catch (RecordStoreException e) {
			names = EMPTY_VECTOR.elements();
		} catch (IOException e) {
			names = EMPTY_VECTOR.elements();
		}
		
		return names;
	}
	
	/**
	 * Get the RecordStore used to store the name to record id mapping.
	 * 
	 * @return
	 * @throws RecordStoreFullException
	 * @throws RecordStoreNotFoundException
	 * @throws RecordStoreException
	 */
	private static RecordStore getNamesStore() 
		throws RecordStoreFullException, RecordStoreNotFoundException, RecordStoreException 
	{
		if (namesStore == null) {
			namesStore = RecordStore.openRecordStore(NAME_STORE, true);
		}
		
		return namesStore;
	}
	
	/**
	 * Get the record id of the record holding the names.
	 * 
	 * @return
	 */
	private static int getNamesRecordID() 
		throws RecordStoreFullException, RecordStoreNotFoundException, RecordStoreException 
	{
		if (namesRecordID == -1) {
			RecordStore store = getNamesStore();
			if (store.getNumRecords() == 0) {
				// Need to create a new record
				namesRecordID = store.addRecord(new byte[0], 0, 0);
			} else {
				// Take the first record in the store as the names mapping record
				RecordEnumeration enum = store.enumerateRecords(null, null, false);
				namesRecordID = enum.nextRecordId();
				enum.destroy();
			}
		}
		
		return namesRecordID;
	}
	
	/**
	 * Get the name to id mapping table.
	 * 
	 * @return
	 * @throws RecordStoreFullException
	 * @throws RecordStoreNotFoundException
	 * @throws RecordStoreException
	 * @throws IOException
	 */
	private static Hashtable getNameToIdMappings() 
		throws RecordStoreFullException, RecordStoreNotFoundException, RecordStoreException, IOException 
	{
		if (nameToIdMapping == null) {
			nameToIdMapping = new Hashtable();
			
			// Read in the mapping data bytes from the store
			RecordStore store = getNamesStore();
			int namesId = getNamesRecordID();
			byte[] mappingBytes = store.getRecord(namesId);
			
			if (mappingBytes != null) {
				// Parse out the data
				ByteArrayInputStream bis = new ByteArrayInputStream(mappingBytes);
				DataInputStream dis = new DataInputStream(bis);
				
				int count = dis.readInt();
				for (int i = 0; i < count; i++) {
					String name = dis.readUTF();
					int id = dis.readInt();
					
					nameToIdMapping.put(name, new Integer(id));
				}
			}
		}
		
		return nameToIdMapping;
	}
	
	/**
	 * Get the RecordStore used to save the contents of the story files.
	 * 
	 * @return
	 * @throws RecordStoreFullException
	 * @throws RecordStoreNotFoundException
	 * @throws RecordStoreException
	 */
	private static RecordStore getDataStore() 
		throws RecordStoreFullException, RecordStoreNotFoundException, RecordStoreException 
	{
		if (dataStore == null) {
			dataStore = RecordStore.openRecordStore(DATA_STORE, true);
		}
		
		return dataStore;
	}
	
	/**
	 * Write out the current names mapping.
	 * 
	 * @throws RecordStoreFullException
	 * @throws RecordStoreNotFoundException
	 * @throws RecordStoreException
	 * @throws IOException
	 */
	static void writeNameToIdMapping() 
		throws RecordStoreFullException, RecordStoreNotFoundException, RecordStoreException, IOException 
	{
		int namesRecordId = getNamesRecordID();
		RecordStore store = getNamesStore();
		Hashtable mappings = getNameToIdMappings();
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		
		dos.writeInt(mappings.size());
		Enumeration keys = mappings.keys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			Integer recId = (Integer) mappings.get(key);
			
			dos.writeUTF(key);
			dos.writeInt(recId.intValue());
		}
		
		dos.flush();
		byte[] bytes = bos.toByteArray();
		
		store.setRecord(namesRecordId, bytes, 0, bytes.length);
	}
	
	private String filename;
	
	/**
	 * Construct a new File instance for the specified file name.
	 * 
	 * @param filename
	 */
	public File(String filename) {
		this.filename = filename;
	}

	/**
	 * Return a boolean indicating whether this file already exists.
	 * 
	 * @return
	 */
	public boolean exists() {
		boolean exists = false;
		
		try {
			exists = (getRecordId() != null);
		} catch (IOException e) {
			// Ignore
		}
		
		return exists;
	}

	/**
	 * Return a boolean indicating whether this file may be read.
	 * 
	 * @return
	 */
	public boolean canRead() {
		return exists();
	}

	/**
	 * Return a boolean indicating whether this is a file.
	 * 
	 * @return
	 */
	public boolean isFile() {
		return true;
	}

	/**
	 * Return the length of the file in bytes or zero if the file
	 * does not already exist.
	 * 
	 * @return
	 */
	public int length() {
		int length = 0;
		
		try {
			Integer id = getRecordId();
			if (id != null) {
				RecordStore store = getDataStore();
				length = store.getRecordSize(id.intValue());
			}
		} catch (Exception e) {
			// Ignore
		}
		
		return length;
	}

	/**
	 * Read the record data or <code>null</code> if not
	 * available.
	 * 
	 * @return
	 * @throws IOException
	 */
	byte[] readRecordData()
		throws IOException 
	{
		byte[] data = null;
		
		Integer id = getRecordId();
		if (id != null) {
			try {
				RecordStore store = getDataStore();
				data = store.getRecord(id.intValue());
			} catch (RecordStoreException e) {
				throw new RecordStoreIOException(e);
			}
		}
		
		return data;
	}
	
	/**
	 * Write the specified data to the appropriate record.
	 * 
	 * @param data
	 * @throws IOException
	 */
	void writeRecordData(byte[] data)
		throws IOException
	{
		Integer id = getRecordId();

		try {		
			RecordStore store = getDataStore();
			if (id == null) {
				// This record has never been written before
				int idValue = store.addRecord(data, 0, data.length);
				id = new Integer(idValue);
				getNameToIdMappings().put(filename, id);
				writeNameToIdMapping();
			} else {
				store.setRecord(id.intValue(), data, 0, data.length);
			}
		} catch (RecordStoreException e) {
			throw new RecordStoreIOException(e); 
		}
	}
	
	/**
	 * Get the record id for this particular "file" or <code>null</code>
	 * if the record does not yet exist.
	 * 
	 * @return
	 */	
	private Integer getRecordId()
		throws IOException 
	{
		try {
			return (Integer) getNameToIdMappings().get(filename);
		} catch (RecordStoreException e) {
			throw new RecordStoreIOException(e);
		}
	}
}
