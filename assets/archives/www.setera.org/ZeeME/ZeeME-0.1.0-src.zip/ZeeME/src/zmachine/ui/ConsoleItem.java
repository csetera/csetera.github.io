/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.StringItem;

import zmachine.util.Settings;
import zmachine.util.StringBufferRing;
import zmachine.util.StringTokenizer;

/**
 * The output console implementation.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.7 $
 * <br>
 * $Date: 2004/09/08 21:15:55 $
 * <br>
 * @author Craig Setera
 */
public class ConsoleItem extends StringItem 
{
	private Settings settings;
	private int[] cursorPosition;
	private int[] fontSize;
	
	private StringBufferRing grid;

	private int height;
	private int width;
	private int lineCount;
	
	/**
	 * Constructor for a new ConsoleItem instance.
	 */
	ConsoleItem(Settings settings) {
		super("", "");
		this.settings = settings;
		calculateBounds();
		
		// Create the grid
		grid = new StringBufferRing(50, 50);
	}
	
	/**
	 * Calculate the bounds of this item. 
	 */
	private void calculateBounds() {
		Canvas c = new Canvas() {
			protected void paint(Graphics arg0) {
			}
		};
		
		width = c.getWidth();
		height = c.getHeight();
		
		Font f = Font.getDefaultFont();
		fontSize = new int[2];
		fontSize[0] = f.charWidth('M');
		fontSize[1] = f.getHeight();
		
		// Steal the space that the text entry
		// field should be from the height of 
		// this item
		height -= (f.getHeight() * 2);

		// Calculate the metrics of the screen given
		// the font
		lineCount = height / fontSize[1];
	}
	
	/**
	 * Copy the specified line contents into the target line.
	 * 
	 * @param srcLine
	 * @param tgtLine
	 */
	private void copyLine(int srcLine, int tgtLine) {
		// copyLineChars(grid[srcLine], grid[tgtLine]);
		System.out.println("copyLine");
	}

	/**
	 * Move to the next line 
	 */
	void nextLine() {
		cursorPosition[0] = 0;
		scrollUp(1);
	}

	/**
	 * Output the specified text without further breaking it down.
	 * 
	 * @param text
	 * @return
	 */
	private void outputTextNoBreak(String text)
	{
		if (text.length() > 0) {
			if ((cursorPosition[0] != 0) || (text.charAt(0) != ' ')) { 
				grid.getCurrent().append(text);
				cursorPosition[0] += text.length();
			}
		}
	}

	/**
	 * Scroll the current grid up the specified number of lines.
	 * 
	 * @param numLines
	 */
	private void scrollUp(int numLines) {
		grid.advance();
	}
	
	/**
	 * Output the specified line of text to the screen, possibly
	 * doing word wrapping to fit the screen.
	 * 
	 * @param line
	 */
	void showLine(String text) {
		// See if we can fit text on to the current line
		if ((cursorPosition[0] + text.length()) < settings.getCharactersPerLine()) {
			outputTextNoBreak(text);
		} else {
			// Nope... break up the string and operate on wordwrap
			StringTokenizer st = new StringTokenizer(text, "\t ", true);
			while (st.hasMoreTokens()) {
				String word = st.nextToken();
				if ((cursorPosition[0] + word.length()) >= settings.getCharactersPerLine()) {
					nextLine();
				}
				
				outputTextNoBreak(word);
			}
		}
	}

	/**
	 * @see zmachine.ZUserInterface#eraseLine(int)
	 */
	void eraseLine(int line) {
		// copyLineChars(blankLine, grid[line]);
		System.out.println("eraseLine: " + line);
	}

	/**
	 * @see zmachine.ZUserInterface#eraseWindow(int)
	 */
	void eraseWindow(int window) {
		for (int i = 0; i < lineCount; i++) {
			eraseLine(i);
		}
	}

	/**
	 * @see zmachine.ZUserInterface#getCursorPosition()
	 */
	int[] getCursorPosition() {
		return cursorPosition;
	}

	/**
	 * @see zmachine.ZUserInterface#getFontSize()
	 */
	int[] getFontSize() {
		return fontSize;
	}

	/**
	 * @see zmachine.ZUserInterface#getScreenCharacters()
	 */
	int[] getScreenCharacters() {
		return new int[] { settings.getCharactersPerLine(), lineCount };
	}

	/**
	 * @see zmachine.ZUserInterface#getScreenUnits()
	 */
	int[] getScreenUnits() {
		int[] units = getFontSize();
		units[0] *= settings.getCharactersPerLine();
		units[1] *= lineCount;
		
		return units;
	}

	/**
	 * @see zmachine.ZUserInterface#getWindowSize(int)
	 */
	int[] getWindowSize(int window) {
		// TODO This is not really correct
		return getScreenCharacters();
	}

	/**
	 * @see zmachine.ZUserInterface#initialize(int)
	 */
	public void initialize(int ver) {
		cursorPosition = new int[] { 0, 0 };
	}

	/**
	 * @see zmachine.ZUserInterface#scrollWindow(int)
	 */
	void scrollWindow(int lines) {
		if (lines < 0) {
			// TODO Fix this...
			System.out.println("scrollWindow down not implemented");
		} else {
			scrollUp(lines);
		}
	}

	/**
	 * @see zmachine.ZUserInterface#setColor(int, int)
	 */
	void setColor(int fg, int bg) {
		System.out.println("setColor");
	}

	/**
	 * @see zmachine.ZUserInterface#setCursorPosition(int, int)
	 */
	void setCursorPosition(int x, int y) {
		cursorPosition[0] = x;
		cursorPosition[1] = y;
	}

	/**
	 * @see zmachine.ZUserInterface#showString(java.lang.String)
	 */
	void showString(String s) {
		try {
			// First, break up the string into lines based on
			// terminating characters
			StringTokenizer lines = new StringTokenizer(s, "\n", false);
			while (lines.hasMoreTokens()) {
				String line = lines.nextToken();
				showLine(line);
				
				if (lines.hasMoreTokens()) {
					nextLine();
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}
		
		// Update our output text
		setText(grid.toString());
	}
}
