/**
 * Copyright (c) 2003-2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

import zmachine.io.File;
import zmachine.io.FileInputStream;
import zmachine.io.FileOutputStream;

/**
 * Holder of settings information.  Also capable of
 * being read and written from a data input/output
 * stream.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/09/08 21:15:55 $
 * <br>
 * @author Craig Setera
 */
public class Settings {
	public static final int CURRENT_VERSION = 1;
	public static final String SETTINGS_FILE = "_SETTINGS_";
	
	private int version;
	private int charactersPerLine;
	
	/**
	 * Construct a new settings object.
	 */
	public Settings() {
		super();
		version = CURRENT_VERSION;
		charactersPerLine = -1;
	}

	/**
	 * @return Returns the screenCharacterWidth.
	 */
	public int getCharactersPerLine() {
		if (charactersPerLine == -1) {
			Font f = Font.getDefaultFont();

			Canvas c = new Canvas() {
				protected void paint(Graphics arg0) {
				}
			};
			
			int width = c.getWidth();
			int fontWidth = f.charWidth('M');
			charactersPerLine = (width / fontWidth) - 1;
			
		}
		
		return charactersPerLine;
	}
	
	/**
	 * @param screenCharacterWidth The screenCharacterWidth to set.
	 */
	public void setCharactersPerLine(int screenCharacterWidth) {
		this.charactersPerLine = screenCharacterWidth;
	}
	
	/**
	 * @return Returns the version.
	 */
	public int getVersion() {
		return version;
	}
	
	/**
	 * @param version The version to set.
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * Read the settings in from the record store.
	 * @throws IOException
	 */
	public void readSettings() throws IOException {
		File settingsFile = new File(SETTINGS_FILE);
		if (settingsFile.exists()) {
			FileInputStream fis = new FileInputStream(SETTINGS_FILE);
			DataInputStream dis = new DataInputStream(fis);
			version = dis.readInt();
			charactersPerLine = dis.readInt();
			dis.close();
		}
	}
	
	/**
	 * Write the settings out to the record
	 * store.
	 * @throws IOException
	 */
	public void writeSettings() throws IOException {
		FileOutputStream fos = new FileOutputStream(SETTINGS_FILE);
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeInt(version);
		dos.writeInt(charactersPerLine);
		dos.close();
	}
}
