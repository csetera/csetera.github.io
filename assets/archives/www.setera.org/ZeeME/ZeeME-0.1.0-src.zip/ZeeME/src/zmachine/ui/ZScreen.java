/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui;

import java.util.Enumeration;
import java.util.Vector;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

import zmachine.ZUserInterface;

/**
 * The Form subclass that handles the 
 * ZScreen.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.6 $
 * <br>
 * $Date: 2004/09/08 21:15:55 $
 * <br>
 * @author Craig Setera
 */
public class ZScreen 
	extends Form
	implements ZUserInterface, CommandListener
{	
	
	/** Form Items */
	private ConsoleItem consoleItem;

	// Current input list
	private Vector inputQueue;
	
	// Tracker for the number of lines written since last input
	// from user
	private int linesOutputSinceInput;
	
	// The midlet the canvas is working for
	private ZeeMEMidlet midlet;
	
	// Current terminating characters
	private char[] terminatingCharacter = new char[] { '\n' };
	private TextField textField;

	private Command[] commands = new Command[] {
		new Command("Input", Command.OK, 1),
		new Command("Settings", Command.OK, 20),
		new Command("Exit", Command.EXIT, 3),
	};
	
	/**
	 * Create a new Form instance to handle the 
	 * screen for the ZMachine.
	 */
	public ZScreen(ZeeMEMidlet midlet) {
		super(null);
		this.midlet = midlet;
		
		// Add the items to the form
		consoleItem = new ConsoleItem(midlet.getSettings());
		append(consoleItem);

		textField = new TextField(null, "", 50, TextField.ANY);
		append(textField);

		// Set up command handling
		setCommandListener(this);
		addCommands();

		// The input queue holds incoming text
		inputQueue = new Vector();
	}

	/**
	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public void commandAction(Command command, Displayable displayable) {
		try {
			int commandIndex = 0;
			for (; commandIndex < commands.length; commandIndex++) {
				if (commands[commandIndex] == command) {
					break;
				}
			}
			
			switch (commandIndex) {
				case 0:
					queueInput(textField.getString());
					textField.setString("");
					break;
		
				case 1:
					promptForSettings();
					break;
					
				case 2:
					midlet.notifyDestroyed();
					break;
					
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	/**
	 * @see zmachine.ZUserInterface#defaultFontProportional()
	 */
	public boolean defaultFontProportional() {
		return false;
	}

	/**
	 * @see zmachine.ZUserInterface#eraseLine(int)
	 */
	public void eraseLine(int s) {
		consoleItem.eraseLine(s);
	}

	/**
	 * @see zmachine.ZUserInterface#eraseWindow(int)
	 */
	public void eraseWindow(int window) {
		consoleItem.eraseWindow(window);
	}

	/**
	 * @see zmachine.ZUserInterface#fatal(java.lang.String)
	 */
	public void fatal(String errmsg) {
		Alert alert = 
			new Alert("Fatal error", errmsg, null, AlertType.ERROR);
		alert.setTimeout(Alert.FOREVER);
		
		Display display = midlet.getDisplay();
		display.setCurrent(alert, display.getCurrent());
		
		quit();
	}

	/**
	 * @see zmachine.ZUserInterface#getCursorPosition()
	 */
	public int[] getCursorPosition() {
		return consoleItem.getCursorPosition();
	}

	/**
	 * @see zmachine.ZUserInterface#getDefaultBackground()
	 */
	public int getDefaultBackground() {
		// TODO This is not correct... Don't know the real colors
		return 0;
	}

	/**
	 * @see zmachine.ZUserInterface#getDefaultForeground()
	 */
	public int getDefaultForeground() {
		// TODO This is not correct... Don't know the real colors
		return 0;
	}

	/**
	 * @see zmachine.ZUserInterface#getFilename(java.lang.String, java.lang.String, boolean)
	 */
	public String getFilename(
		String title,
		String suggested,
		boolean saveFlag) 
	{
		// TODO Need a real implementation of this
		return "zeeme.zav";
	}

	/**
	 * @see zmachine.ZUserInterface#getFontSize()
	 */
	public int[] getFontSize() {
		return consoleItem.getFontSize();
	}

	/**
	 * @see zmachine.ZUserInterface#getScreenCharacters()
	 */
	public int[] getScreenCharacters() {
		return consoleItem.getScreenCharacters();
	}

	/**
	 * @see zmachine.ZUserInterface#getScreenUnits()
	 */
	public int[] getScreenUnits() {
		return consoleItem.getScreenUnits();
	}

	/**
	 * @see zmachine.ZUserInterface#getWindowSize(int)
	 */
	public int[] getWindowSize(int window) {
		return consoleItem.getWindowSize(window);
	}

	/**
	 * @see zmachine.ZUserInterface#hasBoldface()
	 */
	public boolean hasBoldface() {
		return false;
	}

	/**
	 * @see zmachine.ZUserInterface#hasColors()
	 */
	public boolean hasColors() {
		return false;
	}

	/**
	 * @see zmachine.ZUserInterface#hasFixedWidth()
	 */
	public boolean hasFixedWidth() {
		return true;
	}

	/**
	 * @see zmachine.ZUserInterface#hasItalic()
	 */
	public boolean hasItalic() {
		return false;
	}

	/**
	 * @see zmachine.ZUserInterface#hasStatusLine()
	 */
	public boolean hasStatusLine() {
		return true;
	}

	/**
	 * @see zmachine.ZUserInterface#hasUpperWindow()
	 */
	public boolean hasUpperWindow() {
		return false;
	}

	/**
	 * @see zmachine.ZUserInterface#initialize(int)
	 */
	public void initialize(int ver) {
		consoleItem.initialize(ver);
	}

	/**
	 * @see zmachine.ZUserInterface#quit()
	 */
	public void quit() {
		midlet.notifyDestroyed();
	}

	/**
	 * @see zmachine.ZUserInterface#readChar(int)
	 */
	public int readChar(int time) {
		linesOutputSinceInput = 0;

		return 0;
	}

	/**
	 * @see zmachine.ZUserInterface#readLine(java.lang.StringBuffer, int)
	 */
	public int readLine(StringBuffer sb, int time) {
		int returnValue = 0;
		
		try {
			linesOutputSinceInput = 0;
			
			synchronized (inputQueue) {
				if (inputQueue.size() > 0) {
					returnValue = internalReadInputQueueElement(sb);
				} else {
					try {
						inputQueue.wait(time * 100);
					} catch (InterruptedException e) {}
					
					if (inputQueue.size() > 0) {
						returnValue = internalReadInputQueueElement(sb);
					}
				}
			}
			
			if (returnValue != 0) {
				consoleItem.showLine(sb.toString());
				consoleItem.nextLine();
			}
		} catch (Throwable t) { t.printStackTrace(); }
		
		return returnValue;
	}

	/**
	 * @see zmachine.ZUserInterface#restart()
	 */
	public void restart() {
		eraseWindow(0);
	}

	/**
	 * @see zmachine.ZUserInterface#scrollWindow(int)
	 */
	public void scrollWindow(int lines) {
		consoleItem.scrollWindow(lines);
	}

	/**
	 * @see zmachine.ZUserInterface#setColor(int, int)
	 */
	public void setColor(int fg, int bg) {
		consoleItem.setColor(fg, bg);
	}

	/**
	 * @see zmachine.ZUserInterface#setCurrentWindow(int)
	 */
	public void setCurrentWindow(int window) {
		// TODO Fix this...
		System.out.println("setCurrentWindow: " + window);
	}

	/**
	 * @see zmachine.ZUserInterface#setCursorPosition(int, int)
	 */
	public void setCursorPosition(int x, int y) {
		consoleItem.setCursorPosition(x, y);
	}

	/**
	 * @see zmachine.ZUserInterface#setFont(int)
	 */
	public void setFont(int font) {
		// TODO Fix this...
		System.out.println("setFont: " + font);
	}

	/**
	 * @see zmachine.ZUserInterface#setTerminatingCharacters(java.util.Vector)
	 */
	public void setTerminatingCharacters(Vector chars) {
		// TODO Implement this...
		System.out.print("setTerminatingCharacters: ");
		Enumeration enum = chars.elements();
		while (enum.hasMoreElements()) {
			System.out.print(enum.nextElement() + " ");
		}
		System.out.println();
	}

	/**
	 * @see zmachine.ZUserInterface#setTextStyle(int)
	 */
	public void setTextStyle(int style) {
		// TODO Fix this later
		System.out.println("setTextStyle: " + style);
	}

	/**
	 * @see zmachine.ZUserInterface#showStatusBar(java.lang.String, int, int, boolean)
	 */
	public void showStatusBar(String s, int a, int b, boolean flag) {
		StringBuffer sb = new StringBuffer(s);
		sb.append(" (").append(a).append("/").append(b).append(")");
		setTitle(sb.toString());
	}

	/**
	 * @see zmachine.ZUserInterface#showString(java.lang.String)
	 */
	public void showString(String s) {
		consoleItem.showString(s);
	}

	/**
	 * @see zmachine.ZUserInterface#splitScreen(int)
	 */
	public void splitScreen(int lines) {
		// TODO Fix this...
		System.out.println("splitScreen: " + lines);
	}

	/**
	 * Add the commands to this form.
	 */
	private void addCommands() {
		setCommandListener(this);
		for (int i = 0; i < commands.length; i++) {
			addCommand(commands[i]);
		}
	}

	/**
	 * A private method to be called only from the readLine method
	 * within a synchronized block.
	 * 
	 * @param sb
	 * @return
	 */
	private int internalReadInputQueueElement(StringBuffer sb) {
		String command = (String) inputQueue.firstElement();
		inputQueue.removeElementAt(0);
		sb.append(command);

		return 10;
	}

	/**
	 * Prompt the user for settings.
	 */
	private void promptForSettings() {
		SettingsForm settingsForm = 
			new SettingsForm(midlet, this, midlet.getSettings());
		midlet.getDisplay().setCurrent(settingsForm);
		
	}
	
	/**
	 * Queue up some input text.
	 * 
	 * @param text
	 */
	void queueInput(String text) {
		synchronized (inputQueue) {
			inputQueue.addElement(text);
			inputQueue.notifyAll();
		}
	}
}
