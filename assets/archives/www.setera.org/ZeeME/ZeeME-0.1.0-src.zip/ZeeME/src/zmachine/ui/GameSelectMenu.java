/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui;

import java.util.Enumeration;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import zeeme.games.GameCatalog;

/**
 * The menu form for selecting a game to play.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.9 $
 * <br>
 * $Date: 2004/08/31 21:47:16 $
 * <br>
 * @author Craig Setera
 */
public class GameSelectMenu extends List implements CommandListener {
	private ZeeMEMidlet midlet;
	
	/**
	 * Constructor
	 */
	public GameSelectMenu(ZeeMEMidlet midlet) {
		super("ZeeME Select Game", IMPLICIT);
		this.midlet = midlet;
		
		// Fill in the information
		addCommands();
		addGames();
	}

	/**
	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public void commandAction(Command command, Displayable displayable) {
		if (command == List.SELECT_COMMAND) {
			startGame();
		} else {
			switch (command.getCommandType()) {
				case Command.OK:
					break;
				
				case Command.EXIT:
					midlet.notifyDestroyed();
					break;
			}
		}
	}

	/**
	 * Add the commands to this form.
	 */
	private void addCommands() {
		setCommandListener(this);
		addCommand(new Command("Exit", Command.EXIT, 1));
		addCommand(new Command("OK", Command.OK, 1));
	}

	/**
	 * Add the available games to the list. 
	 */
	private void addGames() {
		Enumeration names = GameCatalog.getInstance(midlet).getGameTitles();
		while (names.hasMoreElements()) {
			append((String)names.nextElement(), null);
		}
	}

	/**
	 * Start the selected game. 
	 */
	private void startGame() {
		int selected = getSelectedIndex();
		if (selected != -1) {
			String selectedString = getString(selected);
			midlet.startGame(selectedString);
		}
	}
}
