/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui;

import java.io.IOException;
import java.util.Enumeration;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import zeeme.games.GameCatalog;
import zeeme.games.GameDefinition;
import zmachine.ZCPU;
import zmachine.util.Settings;

/**
 * ZaxME midlet implementation.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.10 $
 * <br>
 * $Date: 2004/09/08 21:15:55 $
 * <br>
 * @author Craig Setera
 */
public class ZeeMEMidlet extends MIDlet {
	
	// current display for this MIDlet
	private Display display;

	// The screen handler
	private ZScreen screen;

	// The currently executing CPU instance
	private ZCPU cpu;

	// The currently running game information
	private GameDefinition currentGameInfo;
	
	// The settings in effect for the game
	private Settings settings;
	
	/**
	 * Constructor
	 */
	public ZeeMEMidlet() {
		super();
		display = Display.getDisplay(this);
		settings = new Settings();
	}

	/**
	 * Get the Display in use by this midlet.
	 * 
	 * @return
	 */
	Display getDisplay() {
		return display;
	}

	/**
	 * @return Returns the settings.
	 */
	Settings getSettings() {
		return settings;
	}
	
	/** Launch the specified game */
	void startGame(String gameName) {
		currentGameInfo = GameCatalog.getInstance(this).getGameInfo(gameName);
		if (currentGameInfo != null) {
			if (currentGameInfo.code != null) {
				launchGame(currentGameInfo, true);					
			} else {
				readCodeAndLaunchGame(currentGameInfo);
			}
		}
	}
	
	/**
	 * @see javax.microedition.midlet.MIDlet#startApp()
	 */
	protected void startApp() throws MIDletStateChangeException {
		Enumeration names = GameCatalog.getInstance(this).getGameTitles();
		String firstName = (String) names.nextElement();
		
		// Try and load the settings...
		try {
			settings.readSettings();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// If there is only a single game, skip the game selection
		// menu
		if (names.hasMoreElements()) {
			GameSelectMenu menu = new GameSelectMenu(this);
			display.setCurrent(menu);
		} else {
			startGame(firstName);
		}
	}

	/**
	 * @see javax.microedition.midlet.MIDlet#pauseApp()
	 */
	protected void pauseApp() {
		// Nothing to do
		System.out.println("pauseApp");
	}

	/**
	 * @see javax.microedition.midlet.MIDlet#destroyApp(boolean)
	 */
	protected void destroyApp(boolean unconditional) 
		throws MIDletStateChangeException 
	{
	}

	/**
	 * Launch the specified game using the information.
	 * 
	 * @param gameInfo the structure containing the information to
	 * be used when running the game.
	 * @param attemptResume whether or not to attempt to resume
	 * a previous version of this game
	 */
	private void launchGame(GameDefinition gameInfo, boolean attemptResume) {
		// Create the "user interface" for the game
		screen = new ZScreen(this);
		cpu = new ZCPU(screen);
		cpu.initialize(gameInfo.name, gameInfo.code);
		
		// Here we go...
		cpu.start();
		getDisplay().setCurrent(screen);
	}

	/**
	 * Read the ZCode and launch the game.
	 * 
	 * @param gameDefinition
	 * @return
	 */
	private void readCodeAndLaunchGame(final GameDefinition gameDefinition) {
		Runnable runnable = new Runnable() {
			public void run() {
				launchGame(gameDefinition, true);
			}
		};
		
		gameDefinition.readCode(getDisplay(), runnable);
	}
}
