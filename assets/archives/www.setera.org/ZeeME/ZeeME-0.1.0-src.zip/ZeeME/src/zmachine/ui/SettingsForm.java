/**
 * Copyright (c) 2003-2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui;

import java.io.IOException;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

import zmachine.util.Settings;

/**
 * A Midlet Form for handling the settings.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/09/08 21:15:55 $
 * <br>
 * @author Craig Setera
 */
public class SettingsForm extends Form implements CommandListener {
	private ZeeMEMidlet midlet;
	private Displayable lastDisplayable;
	private Settings settings;
	private TextField charWidthTextField;
	
	/**
	 * Construct a new form.
	 */
	public SettingsForm(
		ZeeMEMidlet midlet, 
		Displayable lastDisplayable, 
		Settings settings) 
	{
		super("Settings");
		this.midlet = midlet;
		this.lastDisplayable = lastDisplayable;
		this.settings = settings;
		addItems();
		addCommands();
	}

	/**
	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public void commandAction(Command command, Displayable displayable) {
		switch (command.getCommandType()) {
			case Command.OK:
			{
				String value = charWidthTextField.getString();
				int intValue = Integer.parseInt(value);
				settings.setCharactersPerLine(intValue);
				try {
					settings.writeSettings();
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			}
		}
		
		midlet.getDisplay().setCurrent(lastDisplayable);
	}

	/**
	 * Add the settings commands. 
	 */
	private void addCommands() {
		setCommandListener(this);
		addCommand(new Command("OK", Command.OK, 1));
		addCommand(new Command("Cancel", Command.CANCEL, 1));
	}

	/**
	 * Add the form items.
	 */
	private void addItems() {
		charWidthTextField = new TextField(
			"Screen Width  ",
			Integer.toString(settings.getCharactersPerLine()),
			3, TextField.NUMERIC);
		append(charWidthTextField);
	}
}
