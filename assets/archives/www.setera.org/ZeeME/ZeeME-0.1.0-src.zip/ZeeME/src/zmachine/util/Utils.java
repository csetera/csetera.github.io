/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Various static utilities
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/01/18 23:16:46 $
 * <br>
 * @author Craig Setera
 */
public class Utils {
	// The copy buffer
	private static final byte[] buffer = new byte[512];
	
	/**
	 * Copy the contents of the input to the output stream.
	 * 
	 * @param input
	 * @param output
	 * @throws IOException
	 */
	public static void copyInputToOutput(InputStream input, OutputStream output)
		throws IOException
	{
		int bytesRead = 0;
		
		do {
			bytesRead = input.read(buffer, 0, buffer.length);
			if (bytesRead > 0) {
				output.write(buffer, 0, bytesRead);
			}
		} while (bytesRead != -1);
	}

	/**
	 * Private constructor
	 */
	private Utils() {
		super();
	}

}
