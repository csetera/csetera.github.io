/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.io;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Minimal FileInputStream replacement to read from J2ME
 * record store.
 * <p />
 * Copyright (c) 2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/01/18 23:16:46 $
 * <br>
 * @author Craig Setera
 */
public class FileInputStream extends InputStream {
	private File file;
	private ByteArrayInputStream stream; 
	
	/**
	 * Constructor
	 * 
	 * @param f
	 */
	public FileInputStream(File f) {
		file = f;
	}
	
	/**
	 * Constructor
	 * 
	 * @param fn
	 */
	public FileInputStream(String filename) {
		this(new File(filename));
	}

	/**
	 * @see java.io.InputStream#read()
	 */
	public int read() throws IOException {
		return getStream().read();
	}
	
	/**
	 * @see java.io.InputStream#available()
	 */
	public int available() throws IOException {
		return getStream().available();
	}

	/**
	 * @see java.io.InputStream#close()
	 */
	public void close() throws IOException {
		getStream().close();
	}

	/**
	 * @see java.io.InputStream#mark(int)
	 */
	public synchronized void mark(int arg0) {
		// Do nothing
	}

	/**
	 * @see java.io.InputStream#markSupported()
	 */
	public boolean markSupported() {
		return false;
	}

	/**
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	public int read(byte[] arg0, int arg1, int arg2) throws IOException {
		return getStream().read(arg0, arg1, arg2);
	}

	/**
	 * @see java.io.InputStream#read(byte[])
	 */
	public int read(byte[] arg0) throws IOException {
		return getStream().read(arg0);
	}

	/**
	 * @see java.io.InputStream#reset()
	 */
	public synchronized void reset() throws IOException {
		// Ignore
	}

	/**
	 * @see java.io.InputStream#skip(long)
	 */
	public long skip(long arg0) throws IOException {
		return getStream().skip(arg0);
	}

	/**
	 * Get the internal input stream.
	 * 
	 * @return
	 * @throws IOException
	 */
	private InputStream getStream() 
		throws IOException
	{
		if (stream == null) {
			stream = new ByteArrayInputStream(file.readRecordData());
		}
		
		return stream;
	}

}
