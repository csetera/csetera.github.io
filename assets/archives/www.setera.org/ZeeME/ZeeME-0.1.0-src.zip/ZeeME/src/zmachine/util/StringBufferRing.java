/**
 * Copyright (c) 2003-2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.util;

/**
 * A doubly-linked ring of StringBuffer instances
 * that can be traversed in either direction.  It 
 * knows the number of buffers and the current 
 * beginning/ending of the ring.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/08/21 19:32:11 $
 * <br>
 * @author Craig Setera
 */
public class StringBufferRing {
	/**
	 * A doubly-linked StringBuffer Entry class.
	 */
	private class BufferEntry {
		BufferEntry previous;
		BufferEntry next;
		StringBuffer buffer;
		
		/**
		 * Construct a new BufferEntry.
		 * 
		 * @param buffer
		 */
		BufferEntry(StringBuffer buffer) {
			this(buffer, null, null);
		}
		
		/**
		 * Construct a new BufferEntry.
		 * 
		 * @param buffer
		 * @param previous
		 * @param next
		 */
		BufferEntry(StringBuffer buffer, BufferEntry previous, BufferEntry next) {
			this.buffer = buffer;
			this.previous = previous;
			this.next = next;
		}
	}
	
	private int size;
	private BufferEntry first;
	private BufferEntry current;
	private StringBuffer toStringBuffer;
	
	/**
	 * Construct a new buffer ring with the specified
	 * number of buffers.
	 * 
	 * @param size
	 * @param buffersSize the size of each of the StringBuffers
	 * to be allocated in the ring
	 */
	public StringBufferRing(int size, int buffersSize) {
		super();
		this.size = size;
		
		// Create the initial list of buffers with previous
		// pointers set
		first = new BufferEntry(new StringBuffer(buffersSize));
		current = first;
		BufferEntry c = first;
		for (int i = 1; i < size; i++) {
			StringBuffer buffer = new StringBuffer(buffersSize);
			c = new BufferEntry(buffer, c, null);
		}
		
		// Link up the previous of the first
		first.previous = c;
		
		// Now run the list backward and link up the forward
		// pointers
		c = first;
		for (int i = 1; i <= size; i++) {
			c.previous.next = c;
			c = c.previous;
		}
	}

	/**
	 * Advance the current point ahead one buffer.
	 */
	public void advance() {
		if (current.next == first) {
			first.buffer.setLength(0);
			first = first.next;
		}
		
		current = current.next;
	}
	
	/**
	 * Return the current entry in the ring.
	 * 
	 * @return
	 */
	public StringBuffer getCurrent() {
		return current.buffer;
	}
	
	/**
	 * Return the first entry in the ring.
	 * 
	 * @return
	 */
	public StringBuffer getFirst() {
		return first.buffer;
	}
	
	/**
	 * Return the last entry in the ring.
	 * 
	 * @return
	 */
	public StringBuffer getLast() {
		return first.previous.buffer;
	}
	
	/**
	 * Return the number of buffers in the ring.
	 * @return
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * Return a string representation of the string buffer
	 * ring.
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if (toStringBuffer == null) {
			toStringBuffer = new StringBuffer(size * 60);
		} else {
			toStringBuffer.setLength(0);
		}
		
		BufferEntry c = first;
		while (c.next != current) {
			toStringBuffer.append(c.buffer).append('\n');
			c = c.next;
		}
		
		return toStringBuffer.toString();
	}
}
