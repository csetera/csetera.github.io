ZeeME - ZCode Interpreter for J2ME
Version 0.1.0
http://www.gizmo-a-gogo.org/ZeeME
zeeme@gizmo-a-gogo.org

Copyright (c) 2004 Craig Setera
All Rights Reserved
Licensed under the Academic Free License version 2.1
===================
ZeeME is a ZCode interpreter for the J2ME environment. 
ZCode is the intermediate language that was designed 
and used by the original Infocom text adventure games. 
Using ZeeME, it is possible to package and play a large 
variety of interactive fiction on your J2ME mobile device.

ZeeME is shipped with the public domain game "MiniZork".  This
is a demo version of the original Infocom Zork game.  Refer to 
http://www.gizmo-a-gogo.org/ZeeME for more information about ZeeME 
and how to use the ZeeMEPackager functionality to package up a 
version of ZeeME with an available interactive fiction game.

What's New
==========
- Initial release

Features
========
- Should run on any J2ME MIDP 1.0 capable device, given enough memory.
- Should run most Z-code programs of versions 1 through 5.

What's Missing
==============
- Multiple save/restore slots
- Color and graphics support (probably would require MIDP 2.0)

Prerequisites
=============
- J2ME MIDP 1.0 capable device
- Enough memory to load the jar, load the zcode and host the heap.
	The amount of memory will vary tremendously from one Z-Code game to the next.
	
Getting Started
===============
Install the JAR or JAD file as necessary for your mobile device.

Disclaimer
==========
ZeeME and ZeeME packager are provided as-is. There is no warranty 
or guarantee that ZeeME will work as advertised and that it won't 
crater your mobile device. Cratering your device with J2ME is probably 
not very possible, but there are very few guarantees in life.

I hope you enjoy ZeeME, but there is absolutely no support available.