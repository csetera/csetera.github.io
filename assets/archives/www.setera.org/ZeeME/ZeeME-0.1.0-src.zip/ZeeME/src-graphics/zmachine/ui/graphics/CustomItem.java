/**
 * Copyright (c) 2004 Craig Setera
 * All Rights Reserved.
 * Licensed under the Academic Free License version 1.2
 * For more information see http://www.opensource.org/licenses/academic.php
 */
package zmachine.ui.graphics;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.ImageItem;

/**
 * MIDP 2.0 knock off implementation of the CustomItem
 * abstract class.  Does not provide full implementation,
 * just enough to get by.
 * <p />
 * Copyright (c) 2003-2004 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Academic Free License version 1.2<p/>
 * <br>
 * $Revision: 1.1 $
 * <br>
 * $Date: 2004/08/21 19:32:11 $
 * <br>
 * @author Craig Setera
 */
public abstract class CustomItem extends ImageItem {
	private Image offscreenImage;

	public CustomItem(String label) {
		super(label, null, ImageItem.LAYOUT_DEFAULT, "");
	}
	
	protected abstract int getMinContentHeight();
	protected abstract int getMinContentWidth();
	protected abstract int getPrefContentHeight();
	protected abstract int getPrefContentWidth();
	
	protected abstract void paint(Graphics g, int w, int h);
	
	protected void repaint() {
		int width = getPrefContentWidth();
		int height = getPrefContentHeight();

		// Make sure our image has been created...
		if (offscreenImage == null) {
			offscreenImage = Image.createImage(width, height);
		}
		
		// Let the subclass draw to our offscreen image
		Graphics g = offscreenImage.getGraphics();
		paint(g, width, height);
		
		// Make an immutable version and set it into
		// the item
		Image immutable = Image.createImage(offscreenImage);
		setImage(immutable);
	}
}
