/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.util;

import java.util.Vector;

import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.ActiveRichTextField;
import net.rim.device.api.ui.component.RichTextField;

/**
 * Manages the text for a particular {@link RichTextField}
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class RichTextFieldManager {
	private UiApplication application;
	private RichTextField field;
	private Vector textSegments;
	
	public RichTextFieldManager(UiApplication application, RichTextField field) {
		super();
		this.application = application;
		this.field = field;
		this.textSegments = new Vector();
	}
	
	public void addSegment(RichTextFieldSegment segment) {
		textSegments.addElement(segment);
	}
	
	public void removeSegment(RichTextFieldSegment segment) {
		textSegments.removeElement(segment);
	}
	
	public void removeSegment(int segmentIndex) {
		textSegments.removeElementAt(segmentIndex);
	}
	
	public void updateTextField() {
		// This needs to be improved...
		
		// Collect up the rich text information
		int segmentCount = textSegments.size();
		final int[] offsets = new int[segmentCount + 1];
		final Font[] fonts = new Font[segmentCount];
		final byte[] attributes = new byte[segmentCount];
		final int[] backgroundColors = new int[segmentCount];
		final int[] foregroundColors = new int[segmentCount];
		final StringBuffer buffer = new StringBuffer();
		
		offsets[0] = 0;
		for (int i = 0; i < segmentCount; i++) {
			attributes[i] = (byte) i;

			RichTextFieldSegment segment = 
				(RichTextFieldSegment) textSegments.elementAt(i);
			
			buffer.append(segment.getText());
			offsets[i + 1] = buffer.length();
			fonts[i] = segment.getFont();
			backgroundColors[i] = segment.getBackgroundColor();
			foregroundColors[i] = segment.getForegroundColor();
		}
		
		application.invokeLater(new Runnable() {
			public void run() {
				String text = buffer.toString();
				
				if (field instanceof ActiveRichTextField) {
					ActiveRichTextField activeField =
						(ActiveRichTextField) field;
					
					activeField.setText(
						text, 
						offsets, 
						attributes, 
						fonts, 
						foregroundColors, 
						backgroundColors);
				} else {
					field.setText(
						text, 
						offsets, 
						attributes, 
						fonts); 
				}
			}
		});
	}
}
