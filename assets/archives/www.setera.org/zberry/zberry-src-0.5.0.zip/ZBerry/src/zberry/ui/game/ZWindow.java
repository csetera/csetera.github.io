/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import zberry.ui.ZMachineApplication;
import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.RichTextField;

/**
 * Implements a ZMachine window used to separate out the display area
 * of the user interface.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ZWindow extends RichTextField {
	private ZMachineApplication application;

	/**
	 * Construct a new Window for the specified application.
	 * @param application
	 */
	public ZWindow(ZMachineApplication application) {
		super();
		this.application = application;
		setFont(application.getApplicationFont());
	}

	/**
	 * Add the specified text to the output of the ZWindow.
	 * 
	 * @param s
	 */
	public void addString(final String s) {
		application.invokeLater(new Runnable() {
			public void run() {
				// TODO consider "MORE" logic in here somewhere
				
				// Set the new text
				String t = getText() + s;
				setText(t);
				scrollToDisplay();
			}
		});
	}

	/**
	 * Clear the text in the window.
	 */
	public void clearText() {
		application.invokeLater(new Runnable() {
			public void run() {
				setText("");
			}
		});
	}

	/**
	 * Restore the current state from the specified data.
	 * 
	 * @param dis
	 * @throws IOException 
	 */
	public void restoreCurrentState(DataInputStream dis) 
		throws IOException 
	{
		final String text = dis.readUTF();
		application.invokeLater(new Runnable() {
			public void run() {
				setText(text);
				scrollToDisplay();
			}
		});
	}

	/**
	 * Save the current state.
	 * 
	 * @param dos
	 */
	public void saveCurrentState(final DataOutputStream dos) {
		application.invokeAndWait(new Runnable() {
			public void run() {
				try {
					dos.writeUTF(getText());
				} catch (IOException e) {
					e.printStackTrace();
					Dialog.alert(e.getMessage());
				}
			}
		});
	}

	/**
	 * Scroll to display the text
	 */
	private void scrollToDisplay() {
		// Force scroll the output window, only scrolling
		// enough to show the new text if at all possible
		Manager manager = getManager();
		int virtualHeight = manager.getVirtualHeight();
		int actualHeight = manager.getHeight();
		if (virtualHeight > actualHeight) {
			// Scroll things into view
			manager.setVerticalScroll(virtualHeight - actualHeight);
		}
	}
}
