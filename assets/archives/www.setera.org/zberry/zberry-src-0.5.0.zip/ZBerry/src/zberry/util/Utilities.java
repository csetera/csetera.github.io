/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Simple static utility methods.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class Utilities {
	
	/**
	 * Copy the contents of the specified input stream over to the
	 * specified output stream.
	 * 
	 * @param is
	 * @param os
	 * @throws IOException
	 */
	public static void copyInputToOutput(InputStream is, OutputStream os) 
		throws IOException
	{
		int bytesRead = 0;
		byte[] buffer = new byte[512];
		
		while ((bytesRead = is.read(buffer)) != -1) {
			os.write(buffer, 0, bytesRead);
		}
	}
	
	private Utilities() {}
}
