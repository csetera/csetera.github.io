/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.util;

import net.rim.device.api.system.Bitmap;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.FontFamily;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.NumericChoiceField;

/**
 * Implements a Dialog for selection of font family and height. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class FontSelectionDialog extends Dialog {
	
	private FontFamilySelectionField fontFamilyField;
	private NumericChoiceField fontHeightField;
	private Font originalFont;
	private Font currentFont;
	private Field fieldToUpdate;
	
	public FontSelectionDialog(Field fieldToUpdate, Font originalFont) {
		super(
			Dialog.D_OK_CANCEL, 
			"Select Font", 
			Dialog.OK,
			Bitmap.getPredefinedBitmap(Bitmap.QUESTION),
			0);
	
		this.fieldToUpdate = fieldToUpdate;
		this.originalFont = this.currentFont = originalFont;
		
		fontFamilyField = 
			new FontFamilySelectionField(currentFont.getFontFamily());
		add(fontFamilyField);
		
		fontHeightField = new NumericChoiceField("Height", 8, 18, 1);
		add(fontHeightField);
		
		int height = currentFont.getHeight();
		fontHeightField.setSelectedValue(height);

		fontFamilyField.setChangeListener(new FieldChangeListener() {
			public void fieldChanged(Field field, int context) {
				updateFontFamily(fontFamilyField.getSelectedFontFamily());
			}
		});
		fontHeightField.setChangeListener(new FieldChangeListener() {
			public void fieldChanged(Field field, int context) {
				updateFontHeight(fontHeightField.getSelectedValue());
			}
		});
	}

	/**
	 * Return the font that was originally passed in to the dialog.
	 * 
	 * @return
	 */
	public Font getOriginalFont() {
		return originalFont;
	}
	
	/**
	 * Return the font selected by the user or <code>null</code>
	 * if the user cancelled the dialog.
	 * 
	 * @return
	 */
	public Font getSelectedFont() {
		return currentFont;
	}
	
	/**
	 * Update the current font for the specified font family.
	 * 
	 * @param fontFamily
	 */
	private void updateFontFamily(FontFamily fontFamily) {
		currentFont = fontFamily.getFont(
			currentFont.getStyle(), 
			currentFont.getHeight());
		fieldToUpdate.setFont(currentFont);
	}

	/**
	 * Update the current font for the specified font height.
	 * 
	 * @param height
	 */
	protected void updateFontHeight(int height) {
		currentFont = currentFont.derive(currentFont.getStyle(), height);
		fieldToUpdate.setFont(currentFont);
	}
}
