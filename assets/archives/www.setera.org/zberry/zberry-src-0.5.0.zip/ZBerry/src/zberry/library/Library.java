/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.library;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.io.file.FileSystemRegistry;

import zberry.util.FileSystemUtilities;
import zberry.util.Utilities;

/**
 * A class that represents the library holding Story's.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class Library {
	public static final String ZBERRY_FOLDER = "zberry/";
	public static final String SAVES_FOLDER = "saves/";
	public static final String STORIES_FOLDER = "stories/";
	
	private boolean initialized;
	
	/**
	 * Construct a new Library object.
	 */
	public Library() {}
	
	/**
	 * Return the root folder of the library.
	 * 
	 * @return
	 * @throws IOException
	 */
	public Folder getRootFolder() 
		throws IOException 
	{
		if (!initialized) {
			initialize();
			initialized = true;
		}
		
		Folder folder = new Folder(null);
		folder.setName("/");
		
		Enumeration roots = FileSystemRegistry.listRoots();
		while (roots.hasMoreElements()) {
			String rootName = (String) roots.nextElement();
			String url = "file:///" + rootName + ZBERRY_FOLDER + STORIES_FOLDER;
			folder.addURL(url);
		}
		
		return folder;
	}
	
	/**
	 * Initialize the library.
	 * 
	 * @throws IOException 
	 */
	public void initialize() throws IOException {
		String defaultStoryFolder = null;
		
		Enumeration roots = FileSystemRegistry.listRoots();
		while (roots.hasMoreElements()) {
			String rootName = (String) roots.nextElement();
			
			FileConnection root = (FileConnection) Connector.open(
				"file:///" + rootName, 
				Connector.READ_WRITE);
			FileConnection berryFolder = null;
			FileConnection storiesFolder = null;
			FileConnection savesFolder = null;
			
			try {
				berryFolder = initializeFolder(root, ZBERRY_FOLDER);
				storiesFolder = initializeFolder(berryFolder, STORIES_FOLDER);
				savesFolder = initializeFolder(berryFolder, SAVES_FOLDER);
				
				if (
					(defaultStoryFolder == null) || 
					(rootName.equalsIgnoreCase(FileSystemUtilities.SDCARD_ROOT))) 
				{
					defaultStoryFolder = storiesFolder.getURL();
				}
			} finally {
				closeConnection(root);
				closeConnection(berryFolder);
				closeConnection(storiesFolder);
				closeConnection(savesFolder);
			}
		}
		
		// Add a default game to the system
		if (defaultStoryFolder != null) {
			initializeDefaultStory(defaultStoryFolder);
		}
	}

	/**
	 * Close the connection quietly.
	 * 
	 * @param connection
	 */
	private void closeConnection(FileConnection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Initialize the default story file.
	 * 
	 * @param defaultStoryFolder
	 * @throws IOException 
	 */
	private void initializeDefaultStory(String defaultStoryFolder) 
		throws IOException 
	{
		String fileURL = defaultStoryFolder + "minizork.z3";
		FileConnection fc = 
			(FileConnection) Connector.open(fileURL, Connector.READ_WRITE);
		
		InputStream is = null;
		OutputStream os = null;
		if (!fc.exists()) {
			try {
				fc.create();
				is = getClass().getResourceAsStream("minizork.z3");
				os = fc.openOutputStream();
				Utilities.copyInputToOutput(is, os);
			} finally {
				if (os != null) {
					try { os.close(); } catch (IOException e) {}
				}

				if (is != null) {
					try { is.close(); } catch (IOException e) {}
				}
				
				if (fc != null) {
					try { fc.close(); } catch (IOException e) {}
				}
			}
		}
	}

	/**
	 * Initialize the folder.
	 * 
	 * @param parentConnection
	 * @param folderName
	 * @return
	 * @throws IOException
	 */
	private FileConnection initializeFolder(
		FileConnection parentConnection,
		String folderName) 
			throws IOException 
	{
		String folderURL = parentConnection.getURL() + folderName;
		FileConnection folder = 
			(FileConnection) Connector.open(folderURL, Connector.READ_WRITE);
		if (!folder.exists() && parentConnection.canWrite()) {
			folder.mkdir();
		}
		
		return folder;
	}
}
