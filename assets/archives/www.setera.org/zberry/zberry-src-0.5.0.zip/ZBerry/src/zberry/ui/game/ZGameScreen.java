/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.MenuItem;
import net.rim.device.api.ui.Screen;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.Menu;
import zberry.awt.Dimension;
import zberry.awt.Point;
import zberry.core.ApplicationProperties;
import zberry.library.StoryFile;
import zberry.ui.AboutDialog;
import zberry.ui.SelectNewStoryException;
import zberry.ui.ZMachineApplication;
import zberry.ui.util.FontSelectionDialog;
import zberry.util.FileSystemUtilities;
import ZMachine.ZCPU;
import ZMachine.ZUserInterface;

/**
 * Provides the primary game screen displaying the text to the
 * user and allowing text entry. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ZGameScreen 
	extends Screen 
	implements ZUserInterface 
{  
	// How often to auto-save the current state
	private static final int STATE_SAVE_PERIOD = 60000; // 1 minute 
		
	//
	// Timer task for regularly saving the current
	// state of the system.
	//
	private class StateSaveTask extends TimerTask {
		public void run() {
			try {
				saveCurrentState();
			} catch (IOException e) {
				// TODO Need a better approach
				e.printStackTrace();
			}
		}
	}

	//
	// Menu item to open a dialog allowing the user to select
	// a story from the library.
	//
	private class SelectStoryMenuItem extends MenuItem {
		public SelectStoryMenuItem() {
			super("Select Story", 0x00100, 1);
		}

		public void run() {
			stopStoryExecution();
			application.popScreen(ZGameScreen.this);
		}
	};
	
	//
	// Menu item for opening a dialog to allow the user
	// to select a new display font.
	//
	private class SelectFontMenuItem extends MenuItem {
		public SelectFontMenuItem() {
			super("Select Font", 0x00100, 2);
		}

		public void run() {
			FontSelectionDialog dialog = new FontSelectionDialog(
				ZGameScreen.this,
				application.getApplicationFont());
			
			int response = dialog.doModal();

			Font font = (response == Dialog.CANCEL) ? 
				dialog.getOriginalFont() : 
				dialog.getSelectedFont();
			ZGameScreen.this.setFont(font);
			application.setApplicationFont(font);
		}
	}
	
	private ZMachineApplication application;
	private ZScreenLayoutManager screenLayout;
	
	private StoryFile currentStory;
	private ZCPU cpu;
	private Thread executionThread;

	private Timer stateSaveTimer;
	private TimerTask stateSaveTimerTask;

	/**
	 * Construct the game screen for the specified application.
	 * 
	 * @param application
	 */
	public ZGameScreen(ZMachineApplication application) {
		super(
			new ZScreenLayoutManager(application), 
			Screen.DEFAULT_CLOSE | Screen.DEFAULT_MENU);
		this.application = application;
		
		screenLayout = (ZScreenLayoutManager) getDelegate();

		// Get ready to save the current state on a regular
		// basis
		stateSaveTimer = new Timer();
	}

	/**
	 * Layout the game screen
	 */
	protected void sublayout(int width, int height) {
		setPositionDelegate(0, 0);  
		layoutDelegate(width, height);  
		setPosition(0, 0);  
		setExtent(width, height);  
	}

	/**
	 * Return a boolean indicating whether the default font is proportional.
	 */
	public boolean defaultFontProportional() {
		return false;
	}

	public void eraseLine(int s) {
		System.out.println("ZScreen: eraseLine(" + s + ")");
	}

	public void eraseWindow(int window) {
		System.out.println("ZScreen: eraseWindow(" + window + ")");
	}

	public void fatal(String errmsg) {
		System.out.println("ZScreen: fatal(" + errmsg + ")");
	}

	/**
	 * Return the current story.
	 * 
	 * @return
	 */
	public StoryFile getCurrentStory() {
		return currentStory;
	}

	public Point getCursor() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getDefaultBackground() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getDefaultForeground() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Dimension getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	public Dimension getScreenCharacters() {
		// TODO Auto-generated method stub
		return null;
	}

	public Dimension getScreenUnits() {
		// TODO Auto-generated method stub
		return null;
	}

	public Dimension getWindowSize(int window) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean hasBoldface() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean hasColors() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean hasFixedWidth() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean hasItalic() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean hasStatusLine() {
		return true;
	}

	public boolean hasUpperWindow() {
		// TODO Auto-generated method stub
		return false;
	}

	public void initialize(int ver) {
		System.out.println("ZScreen: initialize(" + ver + ")");
	}

	/**
	 * Launch the execution of the specified {@link StoryFile}.
	 * 
	 * @param storyFile
	 */
	public void launchStory(StoryFile storyFile)
		throws SelectNewStoryException
	{
		currentStory = storyFile;
		
		if (storyFile != null) {
			try {
				// Keep track of what we are running
				String url = storyFile.getURL();
				ApplicationProperties props = application.getApplicationProperties();
				props.setCurrentGameFile(url);
				props.store();
				
				// Determine the resume state, if any
				InputStream resumeState = getResumeState(storyFile);
				if (resumeState != null) {
					DataInputStream dis = new DataInputStream(resumeState);
					getStatusBar().restoreCurrentState(dis);
					getCurrentWindow().restoreCurrentState(dis);
				} else {
					getCurrentWindow().clearText();
				}
				
				// Start up the actual Z-Machine CPU
				byte[] code = storyFile.getCode();
				cpu = new ZCPU(this, resumeState);
				cpu.initialize(url, code);
				this.executionThread = cpu.start();
				
				// Start checkpointing the system
				startCheckpointTimer();
				
			} catch (IOException e) {
				e.printStackTrace();
				Dialog.alert(e.getMessage());
			}
		}
	}

	/**
	 * Quit the application.
	 */
	public void quit() {
		application.invokeLater(new Runnable() {
			public void run() {
				getScreen().close();
			}
		});
	}

	public int readChar(int time) {
		System.out.println("ZScreen: readChar(" + time + ")");
		return 0;
	}

	public int readLine(final StringBuffer sb, int time) {
		int terminatingCharacter = getInputField().readLine(sb, time);
		
		if (terminatingCharacter != 0) {
			getCurrentWindow().addString(
				" " + 
				sb.toString() + 
				(char) terminatingCharacter);
		}
		
		return terminatingCharacter;
	}

	public void restart() {
		System.out.println("ZScreen: restart");
	}

	/**
	 * Save the current execution state.
	 * @throws IOException 
	 */
	public void saveCurrentState() 
		throws IOException 
	{
		if ((cpu != null) && (currentStory != null)) {
			String storeURL = currentStory.getSaveURL();
			OutputStream os = null;
			FileConnection storeFile = 
				(FileConnection) Connector.open(storeURL, Connector.READ_WRITE);
			try {
				FileSystemUtilities.createFile(storeFile);
				os = storeFile.openOutputStream();
				
				// Store off the current contents of the 
				// portions of the UI
				DataOutputStream dos = new DataOutputStream(os);
				getStatusBar().saveCurrentState(dos);
				getCurrentWindow().saveCurrentState(dos);
				dos.flush();
				
				// Store off the contents of the running CPU
				cpu.saveState(os);
				
			} finally {
				if (os != null) {
					try { os.close(); } catch (IOException e) {}
				}
				if (storeFile != null) {
					try { storeFile.close(); } catch (IOException e) { }
				}
			}
		}
	}

	public void scrollWindow(int lines) {
		System.out.println("ZScreen: scrollWindow(" + lines + ")");
	}

	public void setColor(int fg, int bg) {
		System.out.println("ZScreen: setColor(" + fg + ", " + bg + ")");
	}

	public void setCurrentWindow(int window) {
		System.out.println("ZScreen: setCurrentWindow(" + window + ")");
	}

	public void setCursor(int x, int y) {
		System.out.println("ZScreen: setCursor(" + x + ", " + y + ")");
	}

	public void setFont(int font) {
		System.out.println("ZScreen: setFont(" + font + ")");
	}

	public void setFont(Font font) {
		super.setFont(font);
		getStatusBar().setFont(font);
		getCurrentWindow().setFont(font);
		getInputField().setFont(font);
	}

	public void setTerminatingCharacters(Vector chars) {
		System.out.println("ZScreen: setTerminatingCharacters");
	}

	public void setTextStyle(int style) {
		System.out.println("ZScreen: setTextStyle(" + style + ")");
	}

	public void showStatusBar(String s, int score, int moves, boolean flag) {
		getStatusBar().showStatus(s, score, moves, flag);
		setFocusToInputField();
	}

	public void showString(final String s) {
		getCurrentWindow().addString(s);
		setFocusToInputField();
	}

	public void splitScreen(int lines) {
		System.out.println("ZScreen: splitScreen(" + lines + ")");
	}

	/**
	 * Return the current window.
	 * 
	 * @return
	 */
	ZWindow getCurrentWindow() {
		return screenLayout.getBottomWindow();
	}
	
	/**
	 * Return the input field for the screen.
	 * 
	 * @return
	 */
	ZInputField getInputField() {
		return screenLayout.getInputField();
	}

	ZStatusBar getStatusBar() {
		return screenLayout.getStatusBar();
	}
	
	/**
	 * Make the menu for the screen.
	 */
	protected void makeMenu(Menu menu, int instance) {
		super.makeMenu(menu, instance);
		menu.add(new SelectStoryMenuItem());
		menu.add(new SelectFontMenuItem());
		menu.add(
			AboutDialog.getAboutMenuItem(
				application.getDefaultFont()));
	}

	/**
	 * The screen has been exposed.
	 */
	protected void onExposed() {
		startCheckpointTimer();
		super.onExposed();		
	}

	/**
	 * Handle the screen being obscured.
	 */
	protected void onObscured() {
		super.onObscured();
		
		stopCheckpointTimer();
		try {
			saveCurrentState();
		} catch (IOException e) {
			// TODO Better handling
			e.printStackTrace();
		}
	}

	/**
	 * Return the resume state as an input stream or <code>null</code>
	 * if restarting or no state is available.
	 * 
	 * @param storyFile 
	 * @return
	 */
	private InputStream getResumeState(StoryFile storyFile)
		throws SelectNewStoryException
	{
		// Determine if we are going to restart or
		// resume...
		InputStream resumeState = storyFile.getSavedState();
		if (resumeState != null) {
			ResumeRestartDialog dialog = 
				new ResumeRestartDialog(storyFile.getName());
			int response = dialog.doModal();

			switch (response) {
				case ResumeRestartDialog.VALUE_RESTART:
					try { resumeState.close(); } catch (IOException e) {}
					resumeState = null;
					break;

				case ResumeRestartDialog.VALUE_SELECT_NEW:
					throw new SelectNewStoryException();
			}
		}
		
		return resumeState;
	}

	/**
	 * Force the focus to the text input field.
	 */
	private void setFocusToInputField() {
		application.invokeLater(new Runnable() {
			public void run() {
				// Force the focus back to the input field
				getInputField().setFocus();
			}
		});
	}

	/**
	 * Start a timer to checkpoint current state.
	 */
	private void startCheckpointTimer() {
		if (getCurrentStory() != null) {
			// Start a task to periodically store the
			// current execution state for later
			// resumption
			stateSaveTimerTask = new StateSaveTask();
			stateSaveTimer.scheduleAtFixedRate(
				stateSaveTimerTask, 
				STATE_SAVE_PERIOD,
				STATE_SAVE_PERIOD);
		}
	}

	/**
	 * Stop the timer to checkpoint current state.
	 */
	private void stopCheckpointTimer() {
		if (stateSaveTimerTask != null) {
			stateSaveTimerTask.cancel();
			stateSaveTimerTask = null;
		}
	}

	/**
	 * Stop a currently executing story.
	 */
	private void stopStoryExecution() {
		// Stop the CPU from running if it is currently running
		if (cpu != null) {
			cpu.stop();
			cpu = null;
		}
		
		// If the thread is running, it is likely waiting on
		// input from the user.  Interrupt it.
		if ((executionThread != null) && executionThread.isAlive()) {
			executionThread.interrupt();
		}
	}

	// Required by the Zplet interface, but unused.
	public InputStream getLoadStream(String title, String suggested) {
		// TODO Auto-generated method stub
		return null;
	}

	// Required by the Zplet interface, but unused.
	public OutputStream getSaveStream(String title, String suggested) {
		// TODO Auto-generated method stub
		return null;
	}
}
