/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.library;

import java.io.IOException;
import java.util.Vector;

/**
 * Abstract superclass of all objects in the library. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public abstract class LibraryObject {
	protected LibraryObject parent;
	protected Vector urls;
	protected String name;
	protected Vector children;
	
	/**
	 * Construct a new library object with the specified parent object.
	 * 
	 * @param parent
	 */
	public LibraryObject(LibraryObject parent) {
		this(parent, null);
	}

	/**
	 * Construct a new library object with the specified parent object
	 * and name.
	 * 
	 * @param parent
	 * @param name
	 */
	public LibraryObject(LibraryObject parent, String name) {
		this.parent = parent;
		this.name = name;
		this.urls = new Vector();
	}
	
	/**
	 * Add a url to this object.
	 * 
	 * @param url
	 */
	public void addURL(String url) {
		urls.addElement(url);
	}

	/**
	 * Return a Vector of {@link LibraryObject} instances
	 * that are the children of this object.
	 * 
	 * @return
	 * @throws IOException
	 */
	public Vector getChildren() 
		throws IOException 
	{
		if (children == null) {
			children = new Vector();
			addChildren(children);
		}
		
		return children;
	}
	
	/**
	 * Return the name of this object.
	 * 
	 * @return
	 */
	public String getName() {
		if ((name == null) && (urls.size() > 0)) {
			String url = (String) urls.elementAt(0);
			
			int startsAt = url.length() - 1;
			if (url.endsWith("/")) {
				startsAt--;
			}
			
			int lastSlash = url.lastIndexOf('/', startsAt);
			if (lastSlash > 0) {
				this.name = url.substring(lastSlash + 1);
			} else {
				this.name = url;
			}
		}
		
		return name;
	}
	
	/**
	 * Get the URLs that drive this object.
	 * 
	 * @return
	 */
	public Vector getURLs() {
		return urls;
	}
	
	/**
	 * Set the name for this object.
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return getClass().getName() + "(" + getName() + ")";
	}

	/**
	 * Add all children to the children vector.
	 * 
	 * @param children
	 * @throws IOException
	 */
	protected abstract void addChildren(Vector children) throws IOException;
}
