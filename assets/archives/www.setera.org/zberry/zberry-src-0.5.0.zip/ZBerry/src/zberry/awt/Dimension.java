/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.awt;

/**
 * Minimal Dimension object for use by the ZMachine library. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class Dimension {

	public int width;
	public int height;
}
