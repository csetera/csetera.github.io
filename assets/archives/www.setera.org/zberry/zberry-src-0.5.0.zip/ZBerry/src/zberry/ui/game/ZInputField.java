/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import java.util.Vector;

import zberry.ui.ZMachineApplication;

import net.rim.device.api.system.Characters;
import net.rim.device.api.ui.component.EditField;

/**
 * Specialized {@link EditField} for text entry into ZBerry 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ZInputField extends EditField {
	private ZMachineApplication application;
	private Vector lines;
	
	/**
	 * Construct a new input field for the specified application.
	 * @param application
	 */
	public ZInputField(ZMachineApplication application) {
		super();
		lines = new Vector();
		this.application = application;
		setFont(application.getApplicationFont());
	}

	/**
	 * Read a line from the user, potentially blocking until
	 * a line becomes available.
	 * 
	 * @param buffer
	 * @param timeout
	 * @return
	 */
	int readLine(StringBuffer buffer, int timeout) {
		int returnValue = 0;
		
		synchronized (lines) {
			returnValue = primReadLine(buffer);
			
			if (returnValue == 0) {
				try {
					// System.out.println("- ZInputField.readLine waiting " + timeout + " for next line");
					if (timeout == 0) {
						lines.wait();
					} else {
						lines.wait(timeout * 100);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				returnValue = primReadLine(buffer);
			}
		}
		
		return returnValue;
	}

	/**
	 * Override handling of particular characters.
	 */
	protected boolean keyChar(char key, int status, int time) {
		boolean handled = false;
		
		if (key == Characters.ENTER) {
			// Track entered lines
			String line = getText();
			setText("");
			
			synchronized (lines) {
				// System.out.println("- ZInputField.keyChar adding new line: " + line);
				lines.addElement(line);
				lines.notifyAll();
			}
			
			handled = true;
		} else {
			handled = super.keyChar(key, status, time); 
		}

		return handled; 
	}

	/**
	 * Read a line from the list without any blocking potential.
	 * 
	 * @param buffer
	 * @return
	 */
	private int primReadLine(StringBuffer buffer) {
		int returnValue = 0;
		
		if (lines.size() > 0) {
			String line = (String) lines.elementAt(0);
			lines.removeElementAt(0);
			
			// System.out.println("- ZInputField.primReadLine appending line: " + line);
			buffer.append(line);
			
			returnValue = '\n';
		}
		
		return returnValue;
	}
}
