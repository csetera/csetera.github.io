/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;

import net.rim.device.api.util.Persistable;

/**
 * Provides a {@link Persistable} implementation
 * of Properties object. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class PersistableProperties extends Hashtable implements Persistable {
	private static final int STATE_START = 0;
	private static final int STATE_COMMENT = 1;
	private static final int STATE_KEY = 2;
	private static final int STATE_VALUE = 3;
	
	public String getProperty(String key) {
		return (String) get(key);
	}
	
	public String getProperty(String key, String defaultValue) {
		String value = getProperty(key);
		if (value == null) value = defaultValue;
		
		return value;
	}
	
	public void load(InputStream is)
		throws IOException
	{
		InputStreamReader reader = new InputStreamReader(is);

		int state = STATE_START;
		int charsRead = 0;
		char[] buffer = new char[128];
		String key = null;
		StringBuffer sb = new StringBuffer();
		
		while ((charsRead = reader.read(buffer)) != -1) {
			for (int i = 0; i < charsRead; i++) {
				char c = buffer[i];
				switch (c) {
					case '#':
						if (state == STATE_START) {
							state = STATE_COMMENT;
						} else {
							sb.append(c);
						}
						break;
						
					case '=':
						if (state == STATE_KEY) {
							key = sb.toString();
							sb.setLength(0);
							state = STATE_VALUE;
						} else if (state == STATE_VALUE) {
							sb.append(c);
						}
						break;
						
					case '\n':
						if (state == STATE_VALUE) {
							put(key, sb.toString());
							key = null;
							sb.setLength(0);
						}
						state = STATE_START;
						break;
						
					default:
						if (state == STATE_START) {
							state = STATE_KEY;
						}
						sb.append(c);
						break;
				}
			}
		}
		
		if ((key != null) && (sb.length() > 0)) {
			put(key, sb.toString());
		}
	}
	
	public void setProperty(String key, String value) {
		put(key, value);
	}
	
	public void store(OutputStream os)
		throws IOException
	{
		PrintStream printer = new PrintStream(os);
		Enumeration keys = keys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = getProperty(key);
			printer.print(key);
			printer.print("=");
			printer.println(value);
		}
		
		printer.close();
	}
}
