/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui;

import zberry.util.Version;
import net.rim.device.api.system.Bitmap;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.MenuItem;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.LabelField;

/**
 * Implementation of the "About" dialog. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class AboutDialog extends Dialog {
	/**
	 * Return a {@link MenuItem} for displaying the About dialog.
	 * 
	 * @param font
	 * @return
	 */
	public static MenuItem getAboutMenuItem(final Font font) {
		if (aboutMenuItem == null) {
			aboutMenuItem = new MenuItem("About", 0x00100, 10) {
				public void run() {
					(new AboutDialog(font)).doModal();
				}
			};
		}
		
		return aboutMenuItem;
	}

	// The text for the about dialog
	public static final String ABOUT_TEXT = 
		"ZBerry Interactive Fiction\n" +
		"Version " + Version.CURRENT_VERSION + "\n" +
		"Copyright (c) 2009\n" +
		"Craig Setera\n\n" +
		"Parts are Copyright (c)\n" + 
		"1996-1997, Matthew E. Kimmel.";
	
	private static MenuItem aboutMenuItem;
	
	/** 
	 * Construct a new About dialog.
	 * 
	 * @param font
	 */
	private AboutDialog(Font font){
		super(
			Dialog.D_OK, 
			"About", 
			Dialog.OK,
			Bitmap.getPredefinedBitmap(Bitmap.INFORMATION),
			0);

		LabelField text = 
			new LabelField(ABOUT_TEXT, Field.FIELD_HCENTER | Field.FIELD_VCENTER);
		text.setFont(font);
		add(text);
	}
}
