/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui;

import java.io.IOException;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.FontFamily;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.Menu;
import net.rim.device.api.ui.container.MainScreen;
import zberry.core.ApplicationProperties;
import zberry.library.Library;
import zberry.library.StoryFile;
import zberry.ui.game.ZGameScreen;
import zberry.ui.library.LibraryTreeField;

/**
 * The top-level UI application class.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ZMachineApplication extends UiApplication {
	private Font defaultFont;
	private Font applicationFont;
	private Library library;
	private MainScreen libraryScreen;
	private ZGameScreen gameScreen;
	private ApplicationProperties properties;
	private boolean initialized;

	public ZMachineApplication() {
		// Derive a reasonably sized font...
		defaultFont = Font.getDefault();
		FontFamily family = defaultFont.getFontFamily();
		defaultFont = family.getFont(defaultFont.getStyle(), 12);
		
		// Construct the available screens
		gameScreen = new ZGameScreen(this);
		
		// Create the library screen
		library = new Library();
		libraryScreen = createLibraryScreen();
		
		// Always push the library screen...
		pushScreen(libraryScreen);
	}

	/**
	 * Get the application properties.
	 * 
	 * @return
	 * @throws IOException
	 */
	public ApplicationProperties getApplicationProperties() {
		if (properties == null) {
			properties = new ApplicationProperties();
			properties.load();
		}
		
		return properties;
	}
	
	/**
	 * Return the default font for use in the application.
	 * 
	 * @return
	 */
	public Font getDefaultFont() {
		return defaultFont;
	}
	
	/**
	 * Return the default font for use by the application.
	 *  
	 * @return
	 * @throws IOException 
	 */
	public Font getApplicationFont() {
		if (applicationFont == null) {
			ApplicationProperties props = getApplicationProperties();
			applicationFont = props.getApplicationFont();
			
			if (applicationFont == null) {
				applicationFont = defaultFont;
			}
		}
		
		return applicationFont;
	}

	/**
	 * Set the application's font and store it for later reference.
	 * 
	 * @param selectedFont
	 * @throws IOException 
	 */
	public void setApplicationFont(Font selectedFont) {
		if (getActiveScreen() instanceof ZGameScreen) {
			((ZGameScreen) getActiveScreen()).setFont(selectedFont);
		}
		
		ApplicationProperties appProps = getApplicationProperties();
		appProps.setApplicationFont(selectedFont);
		appProps.store();
	}

	/**
	 * Launch the specified story.
	 * 
	 * @param selectedStory
	 */
	public void launchStory(StoryFile selectedStory) {
		// Push the game screen on top of the library screen
		pushScreen(gameScreen);
		try {
			gameScreen.launchStory(selectedStory);
		} catch (SelectNewStoryException e) {
			popScreen(gameScreen);
		}
	}

	/**
	 * Activate the application
	 */
	public void activate() {
		if (!initialized) {
			ApplicationProperties props = getApplicationProperties();
			String gameFile = props.getCurrentGameFile();
			if (gameFile != null) {
				StoryFile storyFile = new StoryFile(null, gameFile);
				FileConnection connection = null;
				try {
					connection = (FileConnection) Connector.open(storyFile.getURL());
					if (connection.exists()) {
						launchStory(storyFile);
					}
				} catch (IOException e) {
					e.printStackTrace();
					Dialog.alert(e.getMessage());
				} finally {
					if (connection != null) {
						try {
							connection.close();
						} catch (IOException e) {}
					}
				}
			}

			initialized = true;
		}
		
		super.activate();
	}

	/**
	 * Create the Library Screen.
	 * 
	 * @return
	 */
	private MainScreen createLibraryScreen() {
		MainScreen libraryScreen = new MainScreen() {
			protected void makeMenu(Menu menu, int instance) {
				super.makeMenu(menu, instance);
				menu.add(AboutDialog.getAboutMenuItem(defaultFont));
			}
		};
		
		libraryScreen.setTitle("Select Story");
		LibraryTreeField treeField = new LibraryTreeField(this);
		try {
			treeField.initialize(library);
		} catch (IOException e) {
			e.printStackTrace();
			Dialog.alert(e.getMessage());
		}
		libraryScreen.add(treeField);
		
		return libraryScreen;
	}

	/**
	 * Start up the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ZMachineApplication app = new ZMachineApplication();
		app.enterEventDispatcher();
	}
}
