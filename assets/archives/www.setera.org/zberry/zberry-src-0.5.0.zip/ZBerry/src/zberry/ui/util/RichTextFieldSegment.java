/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.util;

import net.rim.device.api.ui.Font;

/**
 * A segment of rich text.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class RichTextFieldSegment {
	private String text;
	private Font font;
	private int foregroundColor;
	private int backgroundColor;
	
	public RichTextFieldSegment(String text) {
		super();
		this.text = text;
	}

	public RichTextFieldSegment(String text, Font font) {
		super();
		this.text = text;
		this.font = font;
	}

	public RichTextFieldSegment(
		String text, 
		Font font, 
		int foregroundColor,
		int backgroundColor) 
	{
		super();
		this.text = text;
		this.font = font;
		this.foregroundColor = foregroundColor;
		this.backgroundColor = backgroundColor;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Font getFont() {
		return font;
	}

	public void setFont(Font font) {
		this.font = font;
	}

	public int getForegroundColor() {
		return foregroundColor;
	}

	public void setForegroundColor(int foregroundColor) {
		this.foregroundColor = foregroundColor;
	}

	public int getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(int backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
}
