/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.util;

import java.io.IOException;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

/**
 * A set of utilities for dealing with the file system.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class FileSystemUtilities {

	/**
	 * "Well-known?" location of the SD Card.
	 */
	public static final String SDCARD_ROOT = "SDCard";
	private static final String FILE_PROTOCOL = "file:///";

	/**
	 * Create the specified file in the file system if it does
	 * not already exist.  Does nothing if the file already exists.
	 * Recursively creates parent folders as necessary.
	 * 
	 * @param file
	 * @throws IOException 
	 */
	public static void createFile(FileConnection file) 
		throws IOException 
	{
		if (!file.exists()) {
			String parent = getParent(file);
			FileConnection parentConnection =
				(FileConnection) Connector.open(parent, Connector.READ_WRITE);
			
			try {
				createFolder(parentConnection);
			} finally {
				try { parentConnection.close(); } catch (IOException e) {}
			}
			
			file.create();
		}
	}
	
	/**
	 * Recursively create the specified folder and parent folders
	 * as necessary.
	 * 
	 * @param folder
	 * @throws IOException 
	 */
	public static void createFolder(FileConnection folder) 
		throws IOException 
	{
		if (!folder.exists()) {
			String parent = getParent(folder);
			FileConnection parentConnection =
				(FileConnection) Connector.open(parent, Connector.READ_WRITE);
			
			try {
				createFolder(parentConnection);
			} finally {
				try { parentConnection.close(); } catch (IOException e) {}
			}
			
			folder.mkdir();
		}
	}
	
	/**
	 * Return the URL of the parent folder for the specified
	 * file connection.
	 * 
	 * @param fileConnection
	 * @return
	 */
	public static String getParent(FileConnection fileConnection) {
		String parent = null;
		String url = fileConnection.getURL();

		if (!url.equals(FILE_PROTOCOL)) {
			int lastSlash = 0;
			if (url.endsWith("/")) {
				lastSlash = url.lastIndexOf('/', url.length() - 2);
			} else {
				lastSlash = url.lastIndexOf('/');
			}
			
			// Make sure to include the slash...
			if (lastSlash > 0) {
				parent = url.substring(0, lastSlash + 1);
			}
		}
		
		return parent;
	}
	
	private FileSystemUtilities() {}
}
