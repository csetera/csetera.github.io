/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.library;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

/**
 * A {@link Folder} in the {@link Library}.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class Folder extends LibraryObject {

	/**
	 * Construct a new folder with the specified parent object.
	 * 
	 * @param parent
	 */
	public Folder(LibraryObject parent) {
		super(parent);
	}
	
	/** 
	 * Construct a new folder with the specified parent object and name.
	 * 
	 * @param parent
	 * @param name
	 */
	public Folder(LibraryObject parent, String name) {
		super(parent, name);
	}

	/**
	 * Add the folder children (if any) to the vector
	 * of children.
	 * 
	 */
	protected void addChildren(Vector children) 
		throws IOException 
	{
		Hashtable byName = new Hashtable();
		
		Enumeration elements = urls.elements();
		while (elements.hasMoreElements()) {
			String url = (String) elements.nextElement();
			
			FileConnection fc = (FileConnection) Connector.open(url);
			try {
				if (fc.exists()) {
					Enumeration contents = fc.list();
					while (contents.hasMoreElements()) {
						String childName = (String) contents.nextElement();
						String childUrl = url + childName;
						
						LibraryObject obj = (LibraryObject) byName.get(childName);
						if (obj != null) {
							obj.addURL(childUrl);
						} else {
							if (childName.endsWith("/")) {
								obj = new Folder(this);
								obj.addURL(childUrl);
							} else {
								obj = new StoryFile(this, childUrl);
							}
							
							byName.put(childName, obj);
						}
					}
				}
			} finally {
				if (fc != null) {
					try { fc.close(); } catch (IOException e) {}
				}
			}
		}
		
		Enumeration objects = byName.elements();
		while (objects.hasMoreElements()) {
			Object object = (Object) objects.nextElement();
			children.addElement(object);
		}
	}
}
