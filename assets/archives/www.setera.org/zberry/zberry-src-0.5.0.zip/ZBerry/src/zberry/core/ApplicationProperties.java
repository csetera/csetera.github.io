/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.core;

import java.io.IOException;

import net.rim.device.api.system.PersistentObject;
import net.rim.device.api.system.PersistentStore;
import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.FontFamily;
import zberry.util.PersistableProperties;

/**
 * Holds information about application properties
 * and how to store and retrieve those properties.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ApplicationProperties {
	private static final long STORE_KEY = 0x6a563bc6;
	
	private static final String PROP_FONT_FAMILY = "font.family";
	private static final String PROP_FONT_HEIGHT = "font.height";
	private static final String PROP_CURRENT_GAME_FILE = "game.file";
	
	private PersistableProperties properties;
	
	/**
	 * Construct a new properties object.
	 */
	public ApplicationProperties() {
		this.properties = new PersistableProperties();
	}
	
	/**
	 * Return the font to be used by the application.
	 * @return
	 */
	public Font getApplicationFont() {
		Font font = Font.getDefault();
		
		String fontFamily = properties.getProperty(PROP_FONT_FAMILY);
		String fontHeight = properties.getProperty(PROP_FONT_HEIGHT);
		if ((fontFamily != null) && (fontHeight != null)) {
			try {
				FontFamily family = FontFamily.forName(fontFamily);
				int height = Integer.parseInt(fontHeight);
				font = family.getFont(0, height);
			} catch (ClassNotFoundException e) {
			}
		}
		
		return font;
	}
	
	/**
	 * Return the current game file.  This is the file that is
	 * currently running or was running prior to a shutdown of
	 * the application.  This method may return <code>null</code>
	 * in which case the user will need to be prompted for a
	 * game to be run.
	 * 
	 * @return
	 */
	public String getCurrentGameFile() {
		return properties.getProperty(PROP_CURRENT_GAME_FILE);
	}
	
	/**
	 * Load all of the properties.  Any unsaved changes will
	 * be lost by this operation.
	 * 
	 * @throws IOException
	 */
	public void load() {
        PersistentObject persist = 
        	PersistentStore.getPersistentObject(STORE_KEY);

        synchronized(persist) {
            if (persist.getContents() == null) {
                persist.setContents(new PersistableProperties());
                persist.commit();
            }
            
            properties = (PersistableProperties) persist.getContents();
        }
	}
	
	/**
	 * Set the application font.
	 * 
	 * @param font
	 */
	public void setApplicationFont(Font font) {
		properties.setProperty(PROP_FONT_FAMILY, font.getFontFamily().getName());
		properties.setProperty(PROP_FONT_HEIGHT, Integer.toString(font.getHeight()));
	}
	
	/**
	 * Set the current game file.  This is the file that is
	 * currently running or was running prior to a shutdown of
	 * the application.
	 * 
	 * @param url
	 */
	public void setCurrentGameFile(String url) {
		properties.setProperty(PROP_CURRENT_GAME_FILE, url);
	}
	
	/**
	 * Store all of the properties.
	 * 
	 * @throws IOException
	 */
	public void store() {
        PersistentObject persist = 
        	PersistentStore.getPersistentObject(STORE_KEY);

        synchronized (persist) {
            persist.setContents(properties);
            persist.commit();
        }
	}
}
