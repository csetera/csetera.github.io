/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import net.rim.device.api.system.Bitmap;
import net.rim.device.api.ui.component.Dialog;

/**
 * Provides a popup dialog screen for determining whether to 
 * resume a previous game or restart.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ResumeRestartDialog extends Dialog {
	public static final int VALUE_RESUME = 100;
	public static final int VALUE_RESTART = 101;
	public static final int VALUE_SELECT_NEW = 102;
	
	public static final String[] CHOICES = new String[] {
		"Resume",
		"Restart",
		"Select New Game",
	};
	
	public static final int[] VALUES = new int[] {
		VALUE_RESUME,
		VALUE_RESTART,
		VALUE_SELECT_NEW,
	};
	
	public ResumeRestartDialog(String gameName) {
		super(
			"Resume " + gameName + "?",
			(Object[]) CHOICES,
			VALUES,
			VALUE_RESUME,
			Bitmap.getPredefinedBitmap(Bitmap.QUESTION));
	}
}
