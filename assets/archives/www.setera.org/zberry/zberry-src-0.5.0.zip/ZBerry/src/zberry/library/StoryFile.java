/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.library;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;

import zberry.util.Utilities;

/**
 * A story in the library.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class StoryFile extends LibraryObject {
	private String saveURL;
	
	/**
	 * Construct a story file.
	 * 
	 * @param parent
	 * @param url
	 */
	public StoryFile(LibraryObject parent, String url) {
		super(parent);
		this.addURL(url);
	}

	/**
	 * Return the input stream on the code for the story.
	 * 
	 * @return
	 * @throws IOException 
	 */
	public byte[] getCode() 
		throws IOException 
	{
		byte[] code = null;
		
		String url = getURL();
		if (url != null) {
			FileConnection connection = 
				(FileConnection) Connector.open(url);
			if (connection.exists()) {
				InputStream is = null;
				
				try {
					is = connection.openInputStream();
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					Utilities.copyInputToOutput(is, bos);
					code = bos.toByteArray();
				} finally {
					if (is != null) try { is.close(); } catch (IOException e) {}
					if (connection != null) 
						try { connection.close(); } catch (IOException e) {}
				}
			}
		}
		
		return code;
	}

	/**
	 * Return the saved state for this story, if any.  
	 * If none <code>null</code> will be returned.
	 * 
	 * @return
	 */
	public InputStream getSavedState() {
		InputStream savedState = null;
		
		String saveURL = getSaveURL();
		if (saveURL != null) {
			FileConnection file = null;
			try {
				file = (FileConnection) Connector.open(saveURL, Connector.READ);
				if (file.exists()) {
					savedState = file.openInputStream();
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (file != null) {
					try { file.close(); } catch (IOException e) {}
				}
			}
		}

		return savedState;
	}

	/**
	 * Return the URL to use for saving the current state of the 
	 * story execution.
	 * 
	 * @return
	 */
	public String getSaveURL() {
		if (saveURL == null) {
			StringBuffer sb = new StringBuffer();
			
			String url = getURL();
			int storiesIndex = url.indexOf(Library.STORIES_FOLDER);
			if (storiesIndex != -1) {
				// hmm... this shouldn't happen
				sb
					.append(url.substring(0, storiesIndex))
					.append(Library.SAVES_FOLDER)
					.append(url.substring(storiesIndex + Library.STORIES_FOLDER.length()));
			}
			
			saveURL = sb.toString();
		}
		
		return saveURL;
	}
	
	/**
	 * Return the primary URL for this story file.
	 * 
	 * @return
	 */
	public String getURL() {
		String url = null;

		if (urls.size() > 0) {
			url = (String) urls.elementAt(0);
		}
		
		return url;
	}

	protected void addChildren(Vector children) {
		// We have no children, so there is nothing to do here...
	}
}
