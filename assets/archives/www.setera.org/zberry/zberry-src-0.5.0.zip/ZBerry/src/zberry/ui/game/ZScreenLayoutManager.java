/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import zberry.ui.ZMachineApplication;
import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.component.SeparatorField;
import net.rim.device.api.ui.container.VerticalFieldManager;

/**
 * Layout manager implementation for the primary game screen. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
class ZScreenLayoutManager extends Manager {
	private ZMachineApplication application;
	private ZStatusBar statusBar;
	private VerticalFieldManager displayManager;
	private ZWindow topWindow;
	private ZWindow bottomWindow;
	private SeparatorField bottomSeparator;
	private ZInputField inputField;

	/**
	 * Construct a new layout manager for the specified application.
	 * 
	 * @param application
	 */
	ZScreenLayoutManager(ZMachineApplication application) {
		super(0);
		this.application = application;
		
		statusBar = new ZStatusBar(application);
		add(statusBar);
		
		displayManager = new VerticalFieldManager(
				Manager.VERTICAL_SCROLL | 
				Manager.VERTICAL_SCROLLBAR);
		add(displayManager);
		
		topWindow = new ZWindow(application);
		displayManager.add(topWindow);
		
		bottomWindow = new ZWindow(application);
		displayManager.add(bottomWindow);
		
		bottomSeparator = new SeparatorField();
		add(bottomSeparator);
		
		inputField = new ZInputField(application);
		add(inputField);
	}

	/**
	 * Return the screen's status bar.
	 * 
	 * @return
	 */
	public ZStatusBar getStatusBar() {
		return statusBar;
	}

	/**
	 * Return the screen's top window.
	 * 
	 * @return
	 */
	public ZWindow getTopWindow() {
		return topWindow;
	}

	/**
	 * Return the screen's bottom window.
	 * 
	 * @return
	 */
	public ZWindow getBottomWindow() {
		return bottomWindow;
	}

	/**
	 * Return the screen's input field
	 * 
	 * @return
	 */
	public ZInputField getInputField() {
		return inputField;
	}

	/* (non-Javadoc)
	 * @see net.rim.device.api.ui.Manager#sublayout(int, int)
	 */
	protected void sublayout(int width, int height) {
		setExtent(width, height);
		
		// Layout the text input
		layoutChild(inputField, width, height);
		setPositionChild(inputField, 0, height - inputField.getHeight());
		height -= inputField.getHeight();

		// The bottom separator
		layoutChild(bottomSeparator, width, height);
		setPositionChild(bottomSeparator, 0, height - bottomSeparator.getHeight());
		height -= bottomSeparator.getHeight();
		
		// The title
		layoutChild(statusBar, width, height);
		setPositionChild(statusBar, 0, 0);
		height -= statusBar.getHeight();
		
		// The main display
		layoutChild(displayManager, width, height);
		setPositionChild(displayManager, 0, statusBar.getHeight());
	}
}