/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.util;

import net.rim.device.api.ui.FontFamily;
import net.rim.device.api.ui.component.ObjectChoiceField;

/**
 * A specialized Selection field for selection of font family. 
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class FontFamilySelectionField extends ObjectChoiceField {
	//
	// Wrapper around a font family for selection
	//
	private static class FontFamilyWrapper {
		private FontFamily fontFamily;

		public FontFamilyWrapper(FontFamily fontFamily) {
			this.fontFamily = fontFamily;
		}

		public FontFamily getFontFamily() {
			return fontFamily;
		}
		
		public String toString() {
			return fontFamily.getName();
		}
	}
	
	/**
	 * Construct a new font family selection field with the 
	 * initial selection.
	 *  
	 * @param initialSelection
	 */
	public FontFamilySelectionField(FontFamily initialSelection) {
		super();
		
		setLabel("Family");
		FontFamilyWrapper[] wrappers = getChoices();
		setChoices(wrappers);
		
		if (initialSelection != null) {
			for (int i = 0; i < wrappers.length; i++) {
				FontFamilyWrapper wrapper = wrappers[i];
				if (wrapper.getFontFamily().equals(initialSelection)) {
					setSelectedIndex(i);
					break;
				}
			}
		}
	}

	/**
	 * Return the currently selected font family.
	 * 
	 * @return
	 */
	public FontFamily getSelectedFontFamily() {
		FontFamilyWrapper wrapper = 
			(FontFamilyWrapper) getChoice(getSelectedIndex());
		
		return wrapper.getFontFamily();
	}
	
	/**
	 * Return an array of wrappers around the potential font
	 * families found on the device.
	 * 
	 * @return
	 */
	private FontFamilyWrapper[] getChoices() {
		FontFamily[] fontFamilies = FontFamily.getFontFamilies();
		FontFamilyWrapper[] wrappers =
			new FontFamilyWrapper[fontFamilies.length];
		for (int i = 0; i < fontFamilies.length; i++) {
			wrappers[i] = new FontFamilyWrapper(fontFamilies[i]);
		}
		
		return wrappers;
	}
}
