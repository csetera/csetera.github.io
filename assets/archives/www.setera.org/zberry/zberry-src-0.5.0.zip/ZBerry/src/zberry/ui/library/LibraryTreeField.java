/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.library;

import java.io.IOException;
import java.util.Enumeration;

import net.rim.device.api.system.Characters;
import net.rim.device.api.ui.ContextMenu;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.MenuItem;
import net.rim.device.api.ui.component.TreeField;
import zberry.library.Folder;
import zberry.library.Library;
import zberry.library.LibraryObject;
import zberry.library.StoryFile;
import zberry.ui.ZMachineApplication;

/**
 * Specialized TreeField for use in interacting
 * with the library.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class LibraryTreeField extends TreeField {
	//
	// A menu item to launch a selected game.
	//
	private class LaunchGameItem extends MenuItem {
		
		public LaunchGameItem() {
			super("Launch", 0x00100, 1);
		}

		public void run() {
			launchSelectedStory();
		}
	}

	private ZMachineApplication application;
	private LaunchGameItem launchGameItem;
	private StoryFile selectedStory;
	
	/**
	 * Construct a new {@link LibraryTreeField}
	 */
	public LibraryTreeField(ZMachineApplication application) {
		super(new LibraryTreeFieldRenderer(), Field.FOCUSABLE);
		
		this.application = application;
		launchGameItem = new LaunchGameItem();
	}

	/**
	 * Add child nodes for the specified object to the parent.
	 * 
	 * @param parentNode
	 * @param libraryObject
	 * @throws IOException
	 */
	public void addChildNodes(int parentNode, LibraryObject libraryObject) 
		throws IOException 
	{
		Enumeration children = libraryObject.getChildren().elements();
		while (children.hasMoreElements()) {
			LibraryObject child = (LibraryObject) children.nextElement();
			int childNode = addChildNode(parentNode, child);
			setExpanded(childNode, false);
			addChildNodes(childNode, child);
		}
	}
	
	/**
	 * Initialize the tree based on the contents of the specified
	 * Library.
	 * 
	 * @param library
	 * @throws IOException
	 */
	public void initialize(Library library) 
		throws IOException 
	{
		// Start fresh
		deleteAll();
		
		// Recursively fill in the tree...
		Folder rootFolder = library.getRootFolder();
		addChildNodes(0, rootFolder);
	}

	/**
	 * Override key handling to provide special handling for ENTER
	 * key.
	 */
	protected boolean keyChar(char character, int status, int time) {
		boolean handled = false;
		
		if ((character == Characters.ENTER) && (selectedStory != null)) {
			handled = true;
			launchSelectedStory();
		} else {
			handled = super.keyChar(character, status, time);
		}
		
		return handled;
	}

	/**
	 * Launch the currently selected story.
	 */
	protected void launchSelectedStory() {
		if (selectedStory != null) {
			application.launchStory(selectedStory);
		}
	}
	
	/**
	 * Add menu items to the context menu.
	 */
	protected void makeContextMenu(ContextMenu contextMenu) {
		super.makeContextMenu(contextMenu);
		
		if (selectedStory != null) {
			contextMenu.addItem(launchGameItem);
		}
	}

	protected void moveFocus(int x, int y, int status, int time) {
		super.moveFocus(x, y, status, time);
		updateSelectedStory();
	}

	protected int moveFocus(int amount, int status, int time) {
		int value = super.moveFocus(amount, status, time);
		updateSelectedStory();
		
		return value;
	}
	
	/**
	 * Update the currently selected story.
	 * 
	 */
	private void updateSelectedStory() {
		int node = getCurrentNode();
		LibraryObject object = (LibraryObject) getCookie(node);
		if (object instanceof StoryFile) {
			selectedStory = (StoryFile) object;
		} else {
			selectedStory = null;
		}
	}
}
