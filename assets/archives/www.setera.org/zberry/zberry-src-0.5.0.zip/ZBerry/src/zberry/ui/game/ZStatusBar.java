/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.ui.game;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.Graphics;
import net.rim.device.api.ui.Manager;
import zberry.ui.ZMachineApplication;

/**
 * Implements a ZMachine status bar, providing all text rendering.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class ZStatusBar extends Field {
	private static final int DEFAULT_PADDING = 3;
	private int padding = DEFAULT_PADDING;
	private ZMachineApplication application;
	private String statusText;
	private int score;
	private int moves;
	private boolean showTime;
	private StringBuffer buffer;
	
	/**
	 * Construct a new status bar for the specified application.
	 * 
	 * @param application
	 */
	public ZStatusBar(ZMachineApplication application) {
		super(Field.READONLY | Field.NON_FOCUSABLE);
		this.application = application;
		setFont(application.getApplicationFont());
		
		statusText = "Status";
	}

	/**
	 * Restore the current state from the specified data.
	 * 
	 * @param dis
	 * @throws IOException 
	 */
	public void restoreCurrentState(DataInputStream dis) 
		throws IOException 
	{
		moves = dis.readInt();
		score = dis.readInt();
		statusText = dis.readUTF();
		
		forceInvalidate();
	}

	/**
	 * Save the current state of the status buar to the output stream
	 * 
	 * @param dos
	 * @throws IOException 
	 */
	public void saveCurrentState(DataOutputStream dos) 
		throws IOException 
	{
		dos.writeInt(moves);
		dos.writeInt(score);
		dos.writeUTF(statusText);
	}

	/**
	 * Update the status bar to show the provided status
	 * information.
	 * 
	 * @param status
	 * @param score
	 * @param moves
	 * @param showTime
	 */
	public void showStatus(String status, int score, int moves, boolean showTime) {
		this.statusText = status;
		this.score = score;
		this.moves = moves;
		this.showTime = showTime;
		
		forceInvalidate();
	}

	/**
	 * Return the preferred height for the status bar.
	 */
	public int getPreferredHeight() {
		return getFont().getHeight() + (padding * 2);
	}

	/**
	 * Return the preferred width for the status bar.
	 */
	public int getPreferredWidth() {
		Manager mgr = getManager();
		return (mgr == null) ? 100 : mgr.getWidth();
	}

	/**
	 * Return a boolean indicating that this field is not focusable.
	 */
	public boolean isFocusable() {
		return false;
	}

	/**
	 * Layout the field.
	 */
	protected void layout(int width, int height) {
		setExtent(
			Math.min(width, getPreferredWidth()),
			Math.min(height, getPreferredHeight()));
	}

	/**
	 * Custom paint the field contents.
	 */
	protected void paint(Graphics graphics) {
		// Stash the current colors and invert them for the
		// background fill
		int currentBgColor = graphics.getBackgroundColor();
		int currentFgColor = graphics.getColor();
		int w = getWidth();
		int h = getHeight();
		
		graphics.setColor(currentFgColor);
		graphics.fillRect(0, 0, w, h);
		
		graphics.setColor(currentBgColor);
		graphics.setBackgroundColor(currentFgColor);
		
		// Draw the pieces of text
		int midHeight = h / 2;
		int paddedWidth = w - (2 * padding);
		
		buffer = new StringBuffer();
		buffer.setLength(0);
		buffer.append("Moves: ").append(moves);
		graphics.drawText(
			buffer, 
			0, 
			buffer.length(), 
			padding, 
			midHeight, 
			Graphics.VCENTER | Graphics.RIGHT, 
			paddedWidth);
		
		buffer.setLength(0);
		buffer.append("Score: ").append(score);
		graphics.drawText(
			buffer, 
			0, 
			buffer.length(), 
			padding, 
			midHeight, 
			Graphics.VCENTER | Graphics.HCENTER, 
			paddedWidth);
		
		graphics.drawText(
			statusText, 
			padding, 
			midHeight, 
			Graphics.VCENTER | Graphics.LEFT);
	}

	/**
	 * Force the invalid state for the status bar.
	 * 
	 */
	private void forceInvalidate() {
		application.invokeLater(new Runnable() {
			public void run() {
				invalidate();
			}
		});
	}
}
