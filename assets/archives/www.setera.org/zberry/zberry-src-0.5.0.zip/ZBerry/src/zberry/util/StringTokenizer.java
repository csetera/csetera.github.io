/**
 * Copyright (c) 2009 Craig Setera
 * All Rights Reserved.
 * Licensed under the Eclipse Public License - v 1.0
 * For more information see http://www.eclipse.org/legal/epl-v10.html
 */
package zberry.util;

import java.util.Enumeration;
import java.util.Vector;

/**
 * Replacement for the basic StringTokenizer functionality necessary
 * for ZBerry to function.
 * <p />
 * Copyright (c) 2009 Craig Setera<br>
 * All Rights Reserved.<br>
 * Licensed under the Eclipse Public License - v 1.0<p/>
 * <br>
 * @author Craig Setera
 */
public class StringTokenizer {
	private int tokenCount;
	private Enumeration tokens;
	
	/**
	 * Constructor
	 * 
	 * @param toParse
	 * @param tokenSeparators
	 * @param returnDelims
	 */
	public StringTokenizer(
		String toParse, 
		String tokenSeparators, 
		boolean returnDelims) 
	{
		this(toParse, tokenSeparators.toCharArray(), returnDelims);
	}

	/**
	 * Constructor
	 * 
	 * @param toParse
	 * @param tokenSeparators
	 * @param returnDelims
	 */
	public StringTokenizer(
		String toParse,
		char[] tokenSeparators,
		boolean returnDelims)
	{
		Vector v = tokenize(
			toParse, 
			tokenSeparators, 
			returnDelims);
		
		tokenCount = v.size();
		tokens = v.elements();
	}

	/**
	 * Return the number of tokens in the parsed string.
	 * 
	 * @return
	 */
	public int countTokens() {
		return tokenCount;
	}
	
	/**
	 * Return a boolean indicating whether more tokens exist.
	 * @return
	 */
	public boolean hasMoreTokens() {
		return tokens.hasMoreElements();
	}

	/**
	 * Return the next token.
	 * @return
	 */
	public String nextToken() {
		return (String) tokens.nextElement();
	}
	
	/**
	 * Tokenize the specified string, returning the strings 
	 * within that string.
	 * 
	 * @param definition
	 * @return
	 */
	private Vector tokenize(String string, char[] delimiters, boolean includeDelims) {
		Vector tokens = new Vector();
		
		int offset = 0;
		int delimiterIndex = 0;
		
		do {
			delimiterIndex = indexOf(string, delimiters, offset);
			if (delimiterIndex == -1) {
				tokens.addElement(string.substring(offset));
			} else {
				tokens.addElement(string.substring(offset, delimiterIndex));
				if (includeDelims) {
					char delim = string.charAt(delimiterIndex);
					tokens.addElement("" + delim);
				}
				offset = delimiterIndex + 1;
			}
		} while (delimiterIndex != -1);
		
		return tokens;
	}
	
	/**
	 * Return the index of the next character matching any of the specified
	 * delimiters.
	 * 
	 * @param string
	 * @param delimiters
	 * @param offset
	 * @return
	 */
	private int indexOf(String string, char[] delimiters, int offset) {
		int index = -1;
		
		for (int i = offset; i < string.length(); i++) {
			if (isDelimiter(string.charAt(i), delimiters)) {
				index = i;
				break;
			}
		}
		
		return index;
	}
	
	/**
	 * Return a boolean indicating whether the character is in the
	 * delimiter array.
	 * 
	 * @param c
	 * @param delimiters
	 * @return
	 */
	private boolean isDelimiter(char c, char[] delimiters) {
		boolean isDelimiter = false;
		
		for (int j = 0; j < delimiters.length; j++) {
			if (c == delimiters[j]) {
				isDelimiter = true;
				break;
			}
		}

		return isDelimiter;
	}
}
