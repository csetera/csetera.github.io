ZBerry
Interactive Fiction for BlackBerry
Version 0.5.0
=========================================
Welcome to ZBerry.  For more information about ZBerry,
please visit http://www.setera.org/projects/zberry/ .

Have Fun!
=========================================
Copyright (c) 2009 Craig Setera
All Rights Reserved.
Licensed under the Eclipse Public License - v 1.0
